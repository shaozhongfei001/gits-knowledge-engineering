# GITS Bank 测试策略与验证用例集 V1.0

> 本文把V3.2的224项计划用例放进工程阶段与发布门禁，并新增40项当前仓库专项用例。  
> 所有用例初始状态为`PLANNED`；本文件不宣称任何用例已执行。

## 1. 测试目标

测试必须证明“银行岗位能完成任务且责任边界不被AI/前端越过”，而不只是DOM有文字：

- 页面业务逻辑、入口、主动作、下一步和返回上下文正确；
- UI、BFF、API、合同、权限、证据、Action、Gate、回执和审计连续；
- 候选与正式事实分离，Need先于产品，审批/授信/定价责任不被AI继承；
- 弱网、超时、重复提交、版本冲突、撤权、降级和回滚不丢数据、不越权；
- V3.2视觉密度、左导航、工作区标签和清爽配色能在真实内容下保持可读。

## 2. 用例规模

| 来源 | 数量 | 构成 |
|---|---:|---|
| V3.2逐页 | 176 | 44页×正常/权限/异常/恢复4类 |
| V3.2专项 | 48 | 12 E2E + 12契约 + 24质量 |
| 本规划新增 | 40 | 工程基线、CI、架构、合同、安全、性能、a11y、运维发布 |
| 合计 | 264 | 详见06 CSV |

## 3. 测试层次与责任

| 层次 | 主要对象 | 最低自动化 | 责任 | 证据 |
|---|---|---|---|---|
| Static/Type | TS、路由、依赖、合同引用 | 每PR | Feature Pilot | lint/type/diff |
| Unit | Composable、Store、View Model、规则适配 | 每PR | Feature Pilot | 覆盖率/JUnit |
| Component | 四态、权限、键盘、视觉组件 | 每PR | 前端+QA | Vitest/截图 |
| Contract | 21 authority sources、SDK/DTO/consumer | 每PR | Integration Owner | hash/diff/negative test |
| API Integration | H2/真实适配、拒绝路径、幂等 | 每PR/每日 | 后端+QA | HTTP/DB/trace |
| Browser E2E | 两条旅程、44页冒烟、恢复 | 每PR关键集/每日全量 | E2E Owner | Playwright trace/video |
| SIT | 真实系统联调 | 每RC | QA | SIT报告 |
| Independent QA | 独立复跑关键集 | 每RC | 独立QA | QA attestation |
| UAT | 真实岗位任务 | 发布前 | 业务Owner | UAT签署 |
| Release/DR | 灰度、回滚、监控 | 发布前/演练 | SRE+Owner | Runbook/日志 |

## 4. 阶段执行波次

| 阶段 | 必跑集合 | 出口标准 |
|---|---|---|
| P0/P1 | ENG、CI、CTR基础负测 | 环境/注册表/执行数门禁真实有效 |
| P2 | 01—03 + ARC/A11Y/PERF底座 | Shell、组件、四态、键盘、视觉基线通过 |
| P3 | 04—10 + 权限/图谱/列表专项 | 客户与信号切片通过 |
| P4 | 11—19 + E2E-01 + 幂等/恢复 | 持续经营闭环通过 |
| P5 | 20—22、36 + Need边界 | Need→计划→任务连续 |
| P6 | 23—30 + E2E-02/06/07/08 | 建议书闭环通过 |
| P7 | 31—40 + 审批/交付/治理/恢复 | 桌面全功能候选通过 |
| P8 | 41—44 + E2E-04/05 | 移动弱网/撤权/冲突通过 |
| P9 | 224原始+新增适用用例全量 | BLOCKER/MAJOR=0，关键100% |
| P10 | OPS、UAT、回滚、灰度 | Owner批准后发布 |

## 5. 关键E2E数据链断言

### 5.1 持续经营

每步断言`customerId/accountId`、`signalId`、`engagementId/journeyId`、Claim/Evidence引用、操作者、时间、版本和Trace连续。离场前内容仍是客户陈述/待核实；CRM写回必须有差异、确认、幂等和回执。

### 5.2 建议书

每步断言Customer→Need→Service Plan→Proposal→Version→Expert Opinion→Gate Decision→Customer Projection→Delivery Receipt→Account Plan可追溯。产品候选必须反查Need；客户版必须由内部版受控投影；审批中版本不可直接覆盖。

## 6. CI必须整改并验证

1. CI Node改为22+并与`frontend/package.json`、bootstrap一致；
2. 契约检查必须解析`authority_source`，断言检查数量非零；
3. Playwright流水线显式启动后端、前端和测试数据，先健康检查；
4. 输出机器可读Playwright/JUnit结果，关键用例0 skip；
5. 关键控制台错误/页面崩溃零容忍；
6. 不存在对象返回受控4xx/错误Schema，500不算合格；
7. 失败先留证据，不得用`|| true`、警告转成功或测试条件绕过；
8. `make verify`按确定性本地门禁与需外部凭据的环境门禁分层记录。

## 7. 性能、可访问性与安全阈值

- 核心内容P95≤3秒；测量起止、并发、数据量、网络和服务端时间必须固定；
- 大列表虚拟化、大图谱渐进加载，会中长时间录入无数据丢失或内存失控；
- WCAG 2.1 AA、键盘完成两条关键旅程、200%缩放、关系图表格等价；
- 客户范围、字段级权限、用途限制、导出、审批职责分离、审计不可改；
- 移动缓存加密、TTL、设备绑定、撤权/远程清除；
- 埋点、日志、Trace和错误上报不得含未脱敏客户正文。

## 8. 缺陷与通过规则

| 等级 | 例子 | 发布规则 |
|---|---|---|
| BLOCKER | 越权、正式数据错写、不可回滚、关键旅程不可用 | 0 |
| MAJOR | 主动作失败、证据/审批断链、数据丢失、核心a11y阻断 | 0 |
| MINOR | 非关键排版、可绕行体验问题 | 有Owner接受和期限 |
| COSMETIC | 不影响任务的细微视觉差 | 可进入后续优化 |

任何“未执行”“环境不具备”“只用mock”都不能记为PASS；应记`NOT_RUN`、`BLOCKED`或`NOT_APPLICABLE_WITH_APPROVAL`。

## 9. 每条用例证据字段

`test_id, requirement_id, page_id, contract_id, build, commit, environment, actor_role, test_data_version, started_at, actual_result, status, screenshot_or_trace, log_or_receipt, defect_id, reviewer`。

06 CSV已经给出计划字段；实际执行结果必须写入项目批准的测试/Loop证据位置，不要回写本参考包冒充执行记录。
