#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from collections import Counter
from pathlib import Path


ROOT = Path('/workspace/scratch/199ccf8a7c87')
REPO = ROOT / 'repo_review/gits-knowledge-engineering'
V32_ROOT = ROOT / 'outputs/199ccf8a7c87/GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825'
V32_ZIP = ROOT / 'outputs/199ccf8a7c87/GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip'
OUT_PARENT = ROOT / 'outputs/199ccf8a7c87'
PACKAGE_NAME = 'GITS_Bank_UX功能重构_全周期施工与最终交付规划_V1.0_20260825'
OUT = OUT_PARENT / PACKAGE_NAME


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def run(*args: str, cwd: Path = REPO) -> str:
    return subprocess.check_output(args, cwd=cwd, text=True).strip()


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.rstrip() + '\n', encoding='utf-8')


def csv_write(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)


def md_table(headers: list[str], rows: list[list[str]]) -> str:
    def esc(v: object) -> str:
        return str(v).replace('|', '\\|').replace('\n', '<br>')
    lines = ['| ' + ' | '.join(map(esc, headers)) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |']
    lines += ['| ' + ' | '.join(map(esc, row)) + ' |' for row in rows]
    return '\n'.join(lines)


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def phase_for(no: int) -> str:
    if no <= 3:
        return 'P2-体验底座'
    if no <= 10:
        return 'P3-客户与信号'
    if no <= 19:
        return 'P4-互动闭环'
    if no <= 22 or no == 36:
        return 'P5-需求与行动'
    if 23 <= no <= 30:
        return 'P6-建议书工厂'
    if 31 <= no <= 40:
        return 'P7-协同价值治理'
    return 'P8-移动闭环'


ROUTES = {
    1: '/workbench', 2: '/accounts', 3: '/accounts/portfolio',
    4: '/accounts/:accountId/overview', 5: '/accounts/:accountId/relationships',
    6: '/accounts/:accountId/cashflow', 7: '/accounts/:accountId/contacts',
    8: '/signals', 9: '/signals/:signalId', 10: '/engagements',
    11: '/engagements/:engagementId/previsit', 12: '/engagements/:engagementId/previsit/gaps',
    13: '/engagements/:engagementId/previsit/evidence', 14: '/engagements/:engagementId/previsit/pack',
    15: '/engagements/:engagementId/in-meeting', 16: '/engagements/:engagementId/capture',
    17: '/engagements/:engagementId/exit-confirmation', 18: '/engagements/:engagementId/reconciliation',
    19: '/engagements/:engagementId/crm-writeback', 20: '/needs', 21: '/needs/:needId',
    22: '/service-plans/:planId', 23: '/proposals', 24: '/proposals/new',
    25: '/proposals/:proposalId', 26: '/proposals/:proposalId/editor',
    27: '/proposals/:proposalId/mapping', 28: '/proposals/:proposalId/evidence',
    29: '/proposals/:proposalId/projections', 30: '/proposals/:proposalId/versions',
    31: '/collaborations/:collaborationId', 32: '/approvals',
    33: '/proposals/:proposalId/delivery', 34: '/accounts/:accountId/plans',
    35: '/accounts/:accountId/value', 36: '/tasks', 37: '/governance/claims-evidence',
    38: '/knowledge/cards/:cardId', 39: '/governance/audit', 40: '/operations/recovery',
    41: 'mobile://actions', 42: 'mobile://engagements/:id/previsit',
    43: 'mobile://engagements/:id/capture', 44: 'mobile://engagements/:id/exit',
}


CURRENT_ROUTE = {
    1: '/（PARTIAL）', 2: '/（PARTIAL）', 4: '/customers/:id（PARTIAL）',
    10: '/engagement（PARTIAL）', 11: '/engagement（PARTIAL）',
    15: '/in-meeting/:id?（PARTIAL）', 36: '/commitments（PARTIAL）',
    37: '/knowledge-map（RELATED）', 39: '/audit-trace（PARTIAL）',
}


PHASES = [
    {
        'id': 'P0', 'window': 'W0—W1', 'name': '受控接手与开工保护',
        'goal': '锁定仓库、设计输入、Baton、契约哈希、环境与交付口径。',
        'tasks': '校验V3.2 ZIP；读取仓库规则/基线/当前Loop；记录commit与clean status；盘点21个authority source；确认最终交付定义与角色。',
        'outputs': '接手报告、输入清单、契约快照、阻塞清单、RACI、候选新Loop派工。',
        'gate': 'G0：输入可复现；仓库无污染；Owner确认范围；不得进入功能编码。',
    },
    {
        'id': 'P1', 'window': 'W1—W2', 'name': '追踪、架构与契约适配设计',
        'goal': '把44页主动作映射到既有对象、查询、Action、Gate、Evidence和Audit。',
        'tasks': '建立UI事件→View Model→API/BFF→合同ID→authority source→测试；定义路由兼容、上下文Store、错误模型、权限矩阵；修正CI门禁设计。',
        'outputs': '追踪矩阵、ADR候选、接口消费清单、Gap台账、测试数据方案、发布分层。',
        'gate': 'G1：每个主动作=既有契约/前端派生/受控降级三者之一；Gap未静默实现。',
    },
    {
        'id': 'P2', 'window': 'W2—W4', 'name': 'Experience Shell与设计系统',
        'goal': '先形成V3.2统一左导航、工作区标签、对象头、Token和四态组件。',
        'tasks': '重构App Shell；建立主题Token、布局网格、PageReference、Context Store；实现表格/Path/门禁/证据/权限/错误/骨架组件；建立Storybook或等价组件展台。',
        'outputs': '可运行Shell、组件库、视觉回归基线、a11y基线、旧路由兼容策略。',
        'gate': 'G2：核心组件视觉误差受控；键盘/对比度/200%缩放通过；无业务字段发明。',
    },
    {
        'id': 'P3', 'window': 'W3—W6', 'name': '客户、组合、关系与信号垂直切片',
        'goal': '交付页面01—10的真实可操作切片。',
        'tasks': '首页行动队列、客户列表/分层/总览、集团关系、资金全景、关系人、信号列表/详情、互动列表；完成授权过滤、上下文恢复与只读派生。',
        'outputs': '客户经营首个垂直切片、组件复用报告、API消费证据、页面测试。',
        'gate': 'G3A：客户→信号→互动入口连续；权限无泄露；列表和图谱性能达标。',
    },
    {
        'id': 'P4', 'window': 'W5—W8', 'name': '访前—会中—访后—CRM受控写回',
        'goal': '交付页面11—19，形成持续经营第一条关键闭环。',
        'tasks': '访前目标/缺口/证据/访前包；会中速记与转写降级；离场确认；事实对账；CRM差异预览、确认、幂等、回执与补偿。',
        'outputs': '持续经营E2E切片、候选/事实边界证据、写回回执、恢复演练。',
        'gate': 'G3B：未确认内容不进入正式事实；重复点击不重复写；失败可恢复。',
    },
    {
        'id': 'P5', 'window': 'W6—W9', 'name': 'Need、机会、服务计划、任务承诺',
        'goal': '交付页面20—22、36，为建议书提供受控上游输入。',
        'tasks': 'Need对象、根因/目标/约束、服务计划、方案比较、任务/承诺/SLA；保证Need先于产品，机会不等于授信。',
        'outputs': 'Need→Plan→Action追踪、任务SLA、专家入口、可复用选择器。',
        'gate': 'G4A：所有产品候选均可反查Need与适用边界；无额度/价格承诺。',
    },
    {
        'id': 'P6', 'window': 'W8—W12', 'name': '综合服务建议书工厂',
        'goal': '交付页面23—30，形成第二条关键闭环。',
        'tasks': '列表、向导、G0—G5、模块编辑、Need—方案—产品映射、AI依据反查、内外版投影、版本比较恢复；实现草稿并发与审批版本锁定。',
        'outputs': '建议书E2E切片、版本图、投影规则证据、门禁阻断说明、导出候选。',
        'gate': 'G4B：内部版/客户版不分叉；门禁由服务端决定；段落→Claim/Evidence可追溯。',
    },
    {
        'id': 'P7', 'window': 'W10—W13', 'name': '专家、审批、交付、计划、价值与治理',
        'goal': '交付页面31—40并闭合责任、审计、价值和异常恢复。',
        'tasks': '专家协同、冲突裁决、审批中心、对客交付、30/90/180天计划、价值实现、Claim/Evidence、知识边界、权限审计、降级恢复。',
        'outputs': '全桌面功能候选、治理证据、价值口径说明、灾备与补偿演练。',
        'gate': 'G5A：审批/交付/审计责任清楚；不可修改审计；异常不产生未登记副本。',
    },
    {
        'id': 'P8', 'window': 'W11—W14', 'name': '移动端与弱网闭环',
        'goal': '交付页面41—44及桌面—移动连续体验。',
        'tasks': '今日行动、访前包、会中速记、离场确认；本地加密、缓存TTL、撤权清除、弱网暂存、版本冲突、远程清除和设备风险。',
        'outputs': '移动候选、离线策略、设备安全证据、跨端E2E。',
        'gate': 'G5B：撤权清除与冲突恢复通过；未确认数据不写回；敏感缓存受控。',
    },
    {
        'id': 'P9', 'window': 'W13—W15', 'name': 'SIT、性能、安全、a11y与独立QA',
        'goal': '在真实集成环境执行224项V3.2用例与工程发布门禁。',
        'tasks': '全量回归、契约差异、API/页面E2E、权限、幂等、安全、性能、可访问性、跨浏览器、数据恢复；独立QA复跑关键路径。',
        'outputs': 'SIT报告、测试证据、缺陷闭环、独立QA结论、发布风险清单。',
        'gate': 'G6：BLOCKER/MAJOR=0；关键用例100%；CI全绿且E2E实际运行。',
    },
    {
        'id': 'P10', 'window': 'W15—W16+', 'name': 'UAT、发布、灰度与超护',
        'goal': '由真实角色验证并形成可发布、可回滚、可观察的最终功能交付。',
        'tasks': '客户经理/主管/专家/审批/运营UAT；培训；灰度；回滚演练；监控告警；数据核对；超护与缺陷转维。',
        'outputs': 'UAT签署、发布包、Runbook、回滚包、培训材料、监控看板、超护报告。',
        'gate': 'G7：Owner批准发布；未批准不得标记PRODUCTION_READY/FROZEN。',
    },
]


EXTRA_TESTS = [
    ('TC-ENG-001','工程基线','仓库与V3.2输入可复现','记录repo commit、branch、clean status、V3.2 ZIP SHA与解压清单。','全部与批准输入一致；仓库无污染。','P0','P0/G0','P0输入清单、命令日志'),
    ('TC-ENG-002','工程基线','Baton与active Loop','读取LOOP/STATE/NEXT_SESSION/ROLE_BOARD。','Tech Lead有合法Baton；冲突时停止。','P0','P0/G0','Baton截图或文本快照'),
    ('TC-ENG-003','工程基线','44页范围完整导入','将界面清单与追踪导入计划，不复制到specs。','44/44页面有实现波次、路由候选、测试ID。','P0','P1/G1','追踪矩阵'),
    ('TC-ENG-004','工程基线','旧路由兼容','访问当前10条路由和新增目标路由。','批准保留的旧链接可重定向且上下文不丢失。','P1','P2/G2','Playwright trace'),
    ('TC-CI-001','CI','Node版本一致','比较frontend engines、bootstrap-check与CI setup-node。','CI使用Node>=22且锁文件安装成功。','P0','P1/G1','CI日志'),
    ('TC-CI-002','CI','契约检查非空执行','故意在临时测试夹具制造一个缺失authority_source。','契约检查失败且报告缺失文件；0文件检查不得PASS。','P0','P1/G1','CI负测日志'),
    ('TC-CI-003','CI','生成物漂移','在临时副本改变生成物而不改权威源。','make check失败；不得自动接受漂移。','P1','P1/G1','命令日志'),
    ('TC-CI-004','CI','E2E后端就绪','CI启动前后端与测试数据并执行健康检查。','后端UP后才运行Playwright；所有API调用指向受控环境。','P1','P9/G6','CI服务日志'),
    ('TC-CI-005','CI','E2E零跳过门禁','将关键用例skip或未执行。','构建失败；报告明确0跳过策略和执行数。','P1','P9/G6','Playwright JSON/JUnit'),
    ('TC-CI-006','CI','控制台错误零容忍','注入页面崩溃或未处理Promise。','关键旅程失败，不允许“≤2个错误”。','P2','P9/G6','console日志'),
    ('TC-CI-007','CI','错误状态严格断言','请求不存在客户。','返回受控4xx与业务错误；500不得被视为合格。','P3','P9/G6','HTTP/页面证据'),
    ('TC-CI-008','CI','Make verify分层','在无外部DB秘密环境执行确定性检查。','本地门禁可重复；外部DB门禁单独标记且不被软通过。','P0','P1/G1','命令矩阵'),
    ('TC-ARC-001','架构','前端不发明正式字段','扫描View Model、API类型与OpenAPI。','本地派生字段显式隔离；正式字段全可追溯。','P1','P9/G6','类型差异报告'),
    ('TC-ARC-002','架构','展示对象不渗透领域合同','扫描ECharts/UI组件结构。','展示对象只在Experience/前端适配层。','P2','P9/G6','静态扫描'),
    ('TC-ARC-003','架构','四态组件','对核心Query逐一触发Idle/Loading/Success/Error。','无白屏或无限加载；可重试。','P2','P9/G6','组件测试'),
    ('TC-ARC-004','架构','客户上下文一致','从客户下钻至信号/互动/Need/建议书再返回。','accountId和来源PageReference持续且可恢复。','P2','P9/G6','E2E trace'),
    ('TC-ARC-005','架构','主动作服务端授权','篡改前端状态尝试启用按钮。','服务端仍拒绝；前端不决定正式状态。','P2','P9/G6','安全测试'),
    ('TC-ARC-006','架构','组件库单一实现','扫描同类Naive/TDesign组件混用。','同类组件不混用；例外有ADR。','P2','P2/G2','依赖/组件报告'),
    ('TC-CTR-013','契约','21个authority source哈希基线','逐文件计算SHA并与开工快照比对。','未批准阶段21/21一致。','P0','P0/G0','SHA256清单'),
    ('TC-CTR-014','契约','CONTRACT_INDEX唯一注册','扫描实现引用与契约注册。','无旁路注册表、无隐藏合同源。','P1','P9/G6','注册差异报告'),
    ('TC-CTR-015','契约','候选变更阻断','创建未批准候选字段并尝试进入实现。','CI/评审阻断；页面保持降级。','P1','P1/G1','负测PR'),
    ('TC-CTR-016','契约','兼容性与消费者影响','对批准候选运行contract-diff和消费者测试。','无未解释breaking change；迁移/回滚齐全。','P1','P9/G6','差异报告'),
    ('TC-CTR-017','契约','generated只读','在临时分支手改generated。','检查失败；修复路径指向authority source。','P1','P1/G1','负测日志'),
    ('TC-SEC-001','安全','客户范围越权','低权限用户修改accountId访问他人客户。','403/404且不泄露存在性或字段。','P3','P9/G6','访问控制日志'),
    ('TC-SEC-002','安全','字段级脱敏','无敏感字段权限查看/导出/审计。','UI、API、导出、日志均脱敏。','P3','P9/G6','截图与响应'),
    ('TC-SEC-003','安全','审批职责分离','发起人尝试审批自己的受限Action。','按既有规则拒绝或回避。','P7','P9/G6','审计Trace'),
    ('TC-SEC-004','安全','重放与幂等','重放同一Controlled Action请求。','仅一次正式执行；返回相同/可解释回执。','P4','P9/G6','API与DB证据'),
    ('TC-SEC-005','安全','审计防篡改','业务端尝试修改或删除审计条目。','操作不可用且服务端拒绝。','P7','P9/G6','安全测试'),
    ('TC-SEC-006','安全','前端埋点脱敏','捕获分析埋点与错误上报。','不含客户正文、敏感字段、证据原文。','P2','P9/G6','网络日志'),
    ('TC-PERF-001','性能','工作台首屏P95','受控数据量与并发下测工作台。','核心内容P95≤3秒；指标口径固定。','P2','P9/G6','性能报告'),
    ('TC-PERF-002','性能','客户列表虚拟化','加载10万级列表或批准容量。','无一次性DOM爆炸；滚动稳定。','P3','P9/G6','浏览器性能轨迹'),
    ('TC-PERF-003','性能','关系图渐进加载','加载大关系图并切表格等价视图。','分层加载；交互响应达标。','P3','P9/G6','性能轨迹'),
    ('TC-PERF-004','性能','会中长时稳定','连续录入/转写2小时或批准时长。','无数据丢失、内存失控或卡死。','P4','P9/G6','长稳报告'),
    ('TC-A11Y-001','可访问性','键盘核心旅程','不用鼠标完成持续经营与建议书关键动作。','焦点可见、顺序正确、无键盘陷阱。','P2','P9/G6','视频/axe报告'),
    ('TC-A11Y-002','可访问性','读屏语义','读屏浏览对象头、表格、门禁、错误。','名称/角色/状态/错误可理解。','P2','P9/G6','读屏记录'),
    ('TC-A11Y-003','可访问性','200%缩放与回流','桌面浏览器200%缩放。','核心功能无截断、遮挡或横向丢失。','P2','P9/G6','截图'),
    ('TC-OPS-001','运维','灰度回滚','对批准灰度组发布后触发回滚。','旧版本恢复，合同/数据兼容，草稿不丢。','P10','P10/G7','发布回滚日志'),
    ('TC-OPS-002','运维','监控与告警','触发API错误、写回失败、队列积压、AI降级。','告警到正确责任人，含Trace与Runbook。','P9','P10/G7','告警记录'),
    ('TC-OPS-003','运维','数据对账','发布前后核对关键对象与回执。','无未解释增删改；差异可追溯。','P10','P10/G7','对账报告'),
    ('TC-OPS-004','运维','超护退出','统计缺陷、SLA、性能、用户成功率。','达到退出阈值并完成运维交接。','P10','P10/G7','超护报告'),
]


WBS = {
    'P0': [
        ('治理','确认Owner指令、交付终态和非目标','受控范围说明','Owner确认44页、两条旅程、最终交付口径及NO_CHANGE边界'),
        ('接手','核验V3.2 ZIP哈希、清单和状态','输入校验记录','SHA匹配且明确DESIGN_CANDIDATE'),
        ('仓库','记录branch/commit/clean status与规则清单','仓库接手快照','工作区CLEAN；AGENTS/AI_GUIDE/路径规则已读'),
        ('Loop','识别active dispatch/Loop并核对Baton','Baton结论','唯一当前范围和holder明确；冲突即停止'),
        ('契约','解析CONTRACT_INDEX并计算21个唯一源哈希','契约快照','解析数量非零、文件全存在、哈希可复现'),
        ('环境','核对Java/Node/Python/Maven/npm/浏览器版本','环境差距报告','Node 22+等要求与CI/本地一致'),
        ('风险','登记基线状态冲突、权限/数据/外部依赖','开工阻塞清单','每项有Owner、解除条件、截止门'),
    ],
    'P1': [
        ('追踪','将44页、252需求、224测试导入受控追踪','页面需求测试矩阵','44/44有ID、Owner、阶段、测试'),
        ('路由','盘点10条现有路由并设计兼容迁移','路由迁移表','旧深链保留或有批准的重定向/退役计划'),
        ('契约','逐页映射Query/Command到合同ID和authority source','UI—合同追踪','每个主动作完成C0/C1/C2/C3判定'),
        ('架构','设计Experience Shell、Context Store、View Model与BFF边界','ADR候选','正式状态不进入前端裁决；展示对象不渗透领域'),
        ('权限','建立角色×客户范围×字段×动作矩阵','权限矩阵','无权限的查询/按钮/导出/深链行为明确'),
        ('错误','统一API错误、空数组/null、超时、重试、回执语义','错误处理规范','四态和拒绝路径可测试'),
        ('CI','设计Node22、契约非空检查、E2E环境和执行数门禁','CI整改设计','负测能证明门禁不会空通过'),
        ('数据','定义fixture、合成/脱敏数据、角色和版本','测试数据方案','可重复、可清理、无未授权敏感数据'),
        ('派工','创建最小Loop、Gate、exit criteria和RACI','首Loop派工','scope不越界、Baton与证据路径明确'),
    ],
    'P2': [
        ('Shell','实现V3.2左侧分组导航','左导航组件','选中态、折叠、权限过滤和键盘导航通过'),
        ('Shell','实现工作区标签、最近关闭和脏草稿保护','Workspace Tabs','上下文/草稿可恢复且资源释放'),
        ('Shell','实现对象头、面包屑、PageReference和返回恢复','Object Header','跨页保留customerId、来源、页签、滚动'),
        ('设计系统','落地V3.2 Token、字体、间距、色彩与状态语义','Theme Tokens','无旧杂色；状态不只靠颜色'),
        ('组件','实现列表/表格/筛选/保存视图/虚拟化','Data Workspace','空态、分页、性能和权限通过'),
        ('组件','实现Path/Gate/证据/权限/错误/骨架组件','Governed Components','只显示服务端状态，禁用有原因'),
        ('状态','建立Idle/Loading/Success/Error与重试模板','Query State Kit','核心查询四态组件测试通过'),
        ('可访问性','键盘、焦点、读屏、200%缩放基线','a11y报告','核心Shell达到WCAG AA'),
        ('视觉','建立截图基线和关键分辨率视觉回归','视觉回归套件','目标页面结构/密度与V3.2一致，差异可审'),
    ],
    'P3': [
        ('客户','实现01首页行动队列','工作台切片','优先级、快照降级、下钻返回通过'),
        ('客户','实现02客户对象主页','客户列表','范围过滤、保存视图、虚拟化通过'),
        ('组合','实现03客户分层看板','组合看板','拖动只形成提案；无权时禁用'),
        ('客户','实现04客户经营总览','客户360','事实/陈述/核验/假设分层'),
        ('关系','实现05/07集团关系和关系人','关系工作区','证据、敏感字段、候选关系和等价表格通过'),
        ('经营','实现06业务资金全景','业务资金视图','派生数据有来源，不新造正式指标'),
        ('信号','实现08—10信号与互动对象入口','信号互动切片','采纳信号只建经营动作，不直接承诺产品'),
    ],
    'P4': [
        ('访前','实现11访前路径和门禁','访前总控','未满足必填/证据时确定性阻断'),
        ('访前','实现12目标与信息缺口','缺口工作区','缺口可转问题并保留来源'),
        ('证据','实现13知识证据装配','证据夹','来源、日期、权限、冲突/过期可见'),
        ('访前','实现14访前包与版本锁定','访前包','桌面/移动版本一致且可追加紧急证据'),
        ('会中','实现15—16会中捕获、手工降级和自动保存','会中工作区','长时、弱网、转写失败不丢稿'),
        ('离场','实现17离场确认','确认摘要','未确认项不升级为正式事实'),
        ('对账','实现18事实对账与冲突升级','对账工作区','保留双方版本、理由和有权确认人'),
        ('写回','实现19差异预览、确认、幂等、回执和补偿','CRM写回切片','重复提交仅执行一次，失败可查询/重试'),
        ('E2E','自动化持续经营主链与拒绝路径','E2E证据','TC-E2E-01及权限/超时/冲突通过'),
    ],
    'P5': [
        ('Need','实现20需求与机会主页','Need列表','Need和机会语义分开，范围过滤'),
        ('Need','实现21需求记录','Need详情','目标、根因、约束、证据、成功标准完整'),
        ('计划','实现22机会与服务计划','服务计划','创建建议书前置可检查，机会不等于授信'),
        ('任务','实现36任务与承诺中心','任务SLA','责任人、结果/证据、转派和逾期可审计'),
        ('专家','接入请求专家入口和材料清单','专家请求','只发送授权材料，保留版本'),
        ('边界','自动化Need→方案→产品边界测试','边界报告','每个产品候选可反查Need与适用边界'),
    ],
    'P6': [
        ('建议书','实现23列表与筛选','建议书对象主页','客户、阶段、责任人和阻断可筛选'),
        ('建议书','实现24新建向导','向导','客户/Need/用途/模板/事实前置校验通过'),
        ('门禁','实现25 G0—G5记录页','建议书总控','前端只读服务端门禁；越级动作不可用'),
        ('编辑','实现26模块编辑器与自动保存','模块编辑器','AI改写不改变Claim状态；冲突可恢复'),
        ('映射','实现27 Need—方案—产品映射','映射表','完整性检查与适用边界可追溯'),
        ('证据','实现28 AI依据反查','依据检查器','段落—Claim—Evidence双向定位；无权不泄露'),
        ('投影','实现29内部版/客户版受控投影','双版本视图','客户版不手工复制、不形成分叉'),
        ('版本','实现30版本比较与恢复','版本中心','恢复生成新版本；审批版本不可篡改'),
        ('E2E','自动化建议书主链与门禁拒绝路径','建议书E2E证据','TC-E2E-02/06/07/08通过'),
    ],
    'P7': [
        ('协同','实现31专家协同、材料补充和冲突裁决','协同记录','意见版本、SLA、冲突和裁决可审计'),
        ('审批','实现32审批工作中心','审批中心','职责分离、回避、条件、理由和签署完整'),
        ('交付','实现33批准客户版导出/发送/回执','交付中心','只交付批准版本，不产生未登记副本'),
        ('计划','实现34 30/90/180天账户计划','账户计划','行动、责任、时点、证据、KPI和提醒连续'),
        ('价值','实现35价值基线、追踪和复盘','价值实现','指标口径受控；复盘形成下一轮信号'),
        ('证据','实现37 Claim/Evidence治理入口','证据中心','状态治理与报告编辑分离，版本一致'),
        ('知识','实现38知识卡与产品适用边界','知识卡','过期/版本/适用限制可见，加入方案只成候选'),
        ('审计','实现39字段权限和AuditTrace','审计权限页','审计只读、敏感字段用途可验证'),
        ('恢复','实现40降级、重试、补偿和离线包','恢复中心','失败后按幂等键续作并重新校验版本'),
    ],
    'P8': [
        ('移动','实现41今日客户行动','移动行动页','任务优先级与桌面一致，返回位置保留'),
        ('移动','实现42访前包离线缓存','移动访前包','加密、TTL、版本和离线标识明确'),
        ('移动','实现43会中速记与弱网队列','移动速记','断网不丢稿，恢复先比版本'),
        ('移动','实现44离场确认与待同步任务','移动离场','未确认不写回，待同步状态可见'),
        ('安全','实现设备绑定、撤权和远程清除','移动安全机制','撤权/设备风险时缓存不可读并清除'),
        ('跨端','实现桌面发送到移动及状态同步','跨端桥接','同一对象/版本/Trace连续'),
        ('E2E','执行移动弱网、冲突、撤权E2E','移动E2E证据','TC-E2E-04/05通过'),
    ],
    'P9': [
        ('CI','落实Node22、契约非空、真实E2E和报告门禁','全绿CI','关键用例0 skip，失败不可软通过'),
        ('回归','执行224项V3.2与新增专项用例','SIT报告','关键100%，BLOCKER/MAJOR=0'),
        ('契约','执行hash/generate/check/diff/consumer/rejection测试','契约报告','无未解释漂移，受保护源按约束不变'),
        ('性能','执行首屏、列表、图谱、长稳和容量测试','性能报告','P95/容量/长稳达到批准阈值'),
        ('安全','执行越权、字段、职责、重放、审计和埋点测试','安全报告','无高危未处置问题'),
        ('a11y','执行键盘、读屏、缩放、等价视图测试','a11y报告','关键旅程达到WCAG AA'),
        ('兼容','执行浏览器、响应式、打印/导出测试','兼容报告','批准矩阵全部通过'),
        ('恢复','执行超时、重复、冲突、降级、补偿和回滚演练','恢复报告','RTO/RPO或批准恢复目标满足'),
        ('独立QA','独立复跑关键旅程并签署或退回','QA结论','只有独立QA可记录QA_PASS'),
    ],
    'P10': [
        ('UAT','按客户经理/主管/专家/审批/运营角色执行UAT','UAT记录','关键任务成功率和阻断问题达到批准标准'),
        ('培训','完成角色化培训、操作手册和FAQ','培训包','关键用户完成演练并能处理异常'),
        ('发布','冻结RC提交、镜像、合同/资产/数据版本','发布清单','制品可复现、签名/哈希一致'),
        ('灰度','按批准用户组逐级开放','灰度报告','指标不触发回滚阈值'),
        ('监控','上线可用率、P95、Action/Gate/回执/错误监控','监控看板','告警路由和Runbook实测'),
        ('回滚','演练前端/后端/数据/缓存/草稿协同回滚','回滚证据','旧版恢复且数据/合同兼容'),
        ('超护','运行每日复盘、缺陷SLA和用户反馈闭环','超护报告','BLOCKER为0且达到退出阈值'),
        ('交接','转运维、归档证据、关闭Loop并交接Baton','最终交接包','memory/evidence/check齐全，Owner决定发布/冻结'),
    ],
}


def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    screens = load_json(V32_ROOT / '界面清单与追踪_V3.2.json')['screens']
    contract_index = load_json(REPO / 'specs/CONTRACT_INDEX.yaml')
    repo_commit = run('git', 'rev-parse', 'HEAD')
    repo_branch = run('git', 'branch', '--show-current')
    repo_status = run('git', 'status', '--porcelain')
    v32_sha = sha256(V32_ZIP)
    contract_index_sha = sha256(REPO / 'specs/CONTRACT_INDEX.yaml')
    contracts = contract_index['contracts']
    unique_sources = sorted({c['authority_source'] for c in contracts})

    readme = f"""# GITS Bank UX+功能重构：全周期施工与最终交付规划包

> 版本：V1.0 · 日期：2026-08-25 · 状态：`PLANNING_CANDIDATE`  
> 本包是施工规划与门禁包，不是代码实现、SIT/UAT结论、Owner批准或契约变更授权。

## 1. 结论先行

本包把“立即开工”扩展为从受控接手到最终功能交付的完整路线：P0—P10、W0—W16+参考节奏，覆盖44个目标页面、两条业务闭环、契约零覆盖/候选修订流程、224项V3.2原始用例及{len(EXTRA_TESTS)}项新增工程发布门禁用例。

最重要的执行规则：

1. 不要把本包或V3.2包解压覆盖到项目仓库。
2. V3.2是`DESIGN_CANDIDATE`，不是`specs/`、`generated/`或实现代码的替换源。
3. GITS—DKES受保护契约默认`NO_CHANGE`；优先使用既有查询、BFF/View Model组合、前端只读派生或安全降级。
4. 发现真实Gap时先停工、建`CONTRACT_CHANGE_CANDIDATE`，未获Owner/Contract Owner批准不得修改authority source，更不得手改`generated/`。
5. 只有独立QA可记录`QA_PASS`；Owner批准前不得标记`PRODUCTION_READY`或`FROZEN`。

## 2. 指定V3.2输入

- 指定资料库路径：`/飞-银行对公知识工程与岗位智能体/GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip`
- 文件名：`{V32_ZIP.name}`
- SHA-256：`{v32_sha}`
- 内容基线：44张独立高清图、6张总览、252项需求、224项计划测试、逐页业务/UX说明、契约零变更证据。

## 3. 文件阅读顺序

1. `00_README_使用说明.md`（本文件）
2. `01_GITS_Bank_UX功能重构_全周期交付规划_V1.0.md`
3. `02_Cursor_Tech_Lead_V3.2输入包读取与受控开工指南.md`
4. `03_GITS_DKES_契约读取_候选修订_迁移回滚规范.md`
5. `04_GITS_Bank_测试策略与验证用例集_V1.0.md`
6. `05_GITS_Bank_页面_阶段_契约_测试追踪矩阵.csv`
7. `06_GITS_Bank_测试用例执行矩阵.csv`
8. `07_阶段门禁_交付物_RACI_里程碑矩阵.csv`
9. `08_CONTRACT_CHANGE_CANDIDATE_模板.md`
10. `09_Cursor_Tech_Lead_开工提示词.md`
11. `10_工程WBS与验收任务清单.csv`
12. `evidence/`和`QUALITY_REPORT.md`

## 4. 当前核验基线

| 项目 | 值 |
|---|---|
| 仓库分支/提交 | `{repo_branch}` / `{repo_commit}` |
| 仓库工作区 | `{'CLEAN' if not repo_status else 'DIRTY'}` |
| CONTRACT_INDEX SHA-256 | `{contract_index_sha}` |
| 契约记录 / 唯一authority source | {len(contracts)} / {len(unique_sources)} |
| V3.2 ZIP SHA-256 | `{v32_sha}` |
| 规划状态 | `PLANNING_CANDIDATE` |
| 实施/SIT/UAT | `NOT_EXECUTED` |

## 5. Cursor的正确使用方式

把仓库和解压后的参考包作为两个独立根目录读取；先开“只读Tech Lead会话”做追踪和Gap判断，再由获授权的Feature Pilot会话写实现。具体命令、停工条件和提示词见02、08、09号文档。
"""
    write(OUT / '00_README_使用说明.md', readme)

    phase_rows = [[p['id'], p['window'], p['name'], p['goal'], p['outputs'], p['gate']] for p in PHASES]
    main_doc = f"""# GITS Bank UX+功能重构：全周期交付规划 V1.0

> 面向对象：Owner、产品负责人、Tech Lead、前端/BFF/后端、测试、独立QA、运维、安全合规。  
> 输入设计：GITS Bank V3.2。  
> 文档状态：`PLANNING_CANDIDATE`；不直接改变项目任何目录、基线或契约。

## 1. 交付目标与终态定义

本计划的终点不是“画面还原”或“前端能启动”，而是形成可由真实银行岗位完成任务、可审计、可恢复、可发布的功能交付：

- 44个目标页面/子工作区均有可运行实现，V3.2左侧导航、工作区标签、对象头和清爽配色一致落地；
- 客户经理持续经营闭环可走通：信号→互动→访前→会中→访后→事实对账→受控CRM写回→任务/计划/复盘；
- 综合服务建议书闭环可走通：Customer/Need→服务计划→建议书→G0—G5→专家→审批→客户版投影→交付→30/90/180天经营；
- AI只产生候选Claim/Proposal；事实确认、审批、产品/授信/定价承诺、正式写回由有权人员完成；
- 页面动作、权限、Evidence、Controlled Action、HumanGate、回执与AuditTrace可端到端追溯；
- 224项V3.2用例和新增工程发布门禁用例在适用环境留有真实证据；
- UAT通过、发布/回滚/监控/培训齐备，且由Owner作最终发布决定。

状态必须逐级表达：

```text
DESIGN_CANDIDATE
→ IMPLEMENTATION_IN_PROGRESS
→ DEV_SELF_CHECK_PASS
→ SIT_PASS
→ INDEPENDENT_QA_PASS
→ UAT_PASS
→ RELEASE_APPROVED
→ PRODUCTION_READY（仅Owner/发布门禁可授予）
→ FROZEN（仅正式冻结流程可授予）
```

## 2. 权威顺序与不可越界原则

1. 已批准需求、Owner决定与变更记录；
2. `specs/BASELINE_INDEX.yaml`受控输入；
3. 已批准ADR与`specs/CONTRACT_INDEX.yaml`；
4. 当前Loop/Dispatch；
5. 实现代码；
6. V3.2静态图和本规划包。

V3.2提供目标体验、业务逻辑、页面需求和验收候选，但不能反向覆盖更高权威来源。图片与文档冲突时：批准业务/契约 > 验收标准 > 页面说明 > 静态图。

## 3. 当前工程差距（开工前必须正视）

| 发现 | 当前证据 | 对交付的影响 | 计划动作 |
|---|---|---|---|
| 信息架构仍是横向菜单 | `frontend/src/App.vue`的`n-menu mode=horizontal` | 与批准的V3.2左导航/工作区模型不一致 | P2先重构Experience Shell，保留批准的旧深链兼容 |
| 当前只有10条路由（含登录） | `frontend/src/router/index.ts` | 与44页目标存在显著覆盖缺口 | P1建立路由/子工作区映射，P2—P8分波实现 |
| Node版本漂移 | `frontend/package.json`要求>=22；CI使用Node 20 | CI结果不可信或安装失败 | P0/P1统一到Node 22+并负测 |
| 契约检查可能空通过 | CI脚本搜索`path:`，注册表字段实际为`authority_source` | 缺失契约文件可能未被检查 | 改为解析JSON/YAML并断言检查数>0、唯一源=预期值 |
| Playwright环境不完整 | config仅拉起前端；用例直接调用后端API | E2E可能依赖偶然外部进程 | P1定义可复现前后端/数据启动与健康门禁 |
| E2E断言过松 | 当前用例容忍少量崩溃错误；不存在客户可接受500 | 可能“绿测但体验坏” | P1/P9改为关键控制台错误零容忍、受控4xx错误模型 |
| 规则要求四态/vue-query/Tailwind，但依赖与使用需确认 | 仓库规则与当前`package.json`/代码需逐项比对 | 贸然引入依赖或绕过规则均有风险 | P1形成ADR/依赖决策；未批准不擅自替换框架 |
| 现有页面更多是局部原型 | 当前Dashboard/Engagement/Commitment等 | 不能用“改皮肤”替代对象模型和旅程重构 | 以垂直切片逐步替换并保留可回滚开关 |

以上是截至`{repo_commit}`的只读观察；Tech Lead开工时必须重新核验。

## 4. 目标工程架构

```text
Route / PageReference
  → Experience Shell（左导航、工作区标签、对象头）
  → Workspace Context Store（仅UI上下文与草稿引用）
  → Page / Feature Modules
  → Query / Command View Model Adapter
  → BFF / Existing API Client
  → 已注册GITS—DKES Contracts

写操作：User Intent
  → 服务端可执行性/权限/门禁查询
  → 差异预览
  → 人工确认
  → Controlled Action / HumanGate / CRM Writeback
  → Receipt / AuditTrace
```

Experience层可以持有筛选、排序、工作区标签、滚动位置、未提交草稿引用和纯展示派生字段；不得持有或裁决正式事实、审批结论、G0—G5阶段、授信、定价或写回结果。

## 5. 全周期工程阶段

参考节奏为W0—W16+，假设8—12人跨职能团队、目标环境/测试数据及时可用、受保护契约保持零变更。它是计划基线，不是日期或上线承诺。

{md_table(['阶段','参考窗口','主题','目标','主要产物','出口门禁'], phase_rows)}

## 6. 阶段详细任务与退出标准

"""
    for p in PHASES:
        main_doc += f"""
### {p['id']} {p['name']}（{p['window']}）

- 目标：{p['goal']}
- 工程任务：{p['tasks']}
- 交付物：{p['outputs']}
- 出口门禁：{p['gate']}
- 证据最低要求：关联Loop ID、分支、提交、构建号、环境、执行者、时间、命令/日志/截图/回执和未决缺陷；开发角色只能记录`DEV_SELF_CHECK_PASS`。
"""
    main_doc += f"""
## 7. 页面实施分包

| 分包 | 页面范围 | 业务价值 | 允许开始的前置 | Done标准 |
|---|---|---|---|---|
| WP-UX-FND | 01—03 | 统一行动入口、客户对象和组合管理 | P1追踪完成、Shell ADR通过 | 左导航/标签/对象头/返回恢复可用 |
| WP-CUST | 04—10 | 客户全景、关系、资金、信号与互动入口 | 客户/关系/证据查询契约映射完成 | 授权过滤、派生只读、图表等价视图通过 |
| WP-ENG | 11—19 | 持续经营核心闭环 | Evidence/Action/Gate/Writeback映射完成 | 候选/事实/回写/回执可追溯 |
| WP-NEED | 20—22、36 | Need、服务计划、任务承诺 | Need/Action现有能力确认 | Need先于产品；SLA与责任可验证 |
| WP-PROP | 23—30 | 建议书工厂 | 上游Need、证据、版本、门禁能力确认 | G0—G5、内外版、版本、证据闭环 |
| WP-GOV | 31—40 | 专家、审批、交付、价值、证据、权限、恢复 | Gate/Audit/Knowledge/Action映射完成 | 职责分离、审计不可改、异常可恢复 |
| WP-MOB | 41—44 | 移动访前—会中—离场 | 设备安全/缓存/撤权方案批准 | 弱网、冲突、清除、跨端连续通过 |

逐页阶段、候选路由、当前覆盖、需求ID与测试ID见`05_GITS_Bank_页面_阶段_契约_测试追踪矩阵.csv`；可直接拆进工程看板的任务、依赖、责任、验收和证据要求见`10_工程WBS与验收任务清单.csv`。

## 8. 契约策略：零覆盖、零静默变更

本项目对受保护GITS—DKES边界采取四级判定：

| 级别 | 判定 | 处理 |
|---|---|---|
| C0 | 既有合同直接支持 | 复用现有SDK/API；写消费测试 |
| C1 | 仅需查询组合或展示派生 | 在BFF/View Model/前端适配层实现，不写回、不污染领域合同 |
| C2 | 现有合同不支持但功能可安全降级 | 只读、禁用或降级，显示原因和解除路径 |
| C3 | 不变更合同无法完成关键业务 | 建候选变更并停在审批门；当前“GITS—DKES不能变更”要求下不得擅自实施 |

实际修改顺序永远是：批准需求/Owner决定→候选ADR/兼容评估→authority source→`CONTRACT_INDEX`→`make generate`→`make check`/diff→消费者→实现→全量回归。`generated/`不得手改。

## 9. 测试与证据策略

- 继承V3.2的224项：176项逐页用例+12项E2E+12项契约+24项质量用例；
- 新增{len(EXTRA_TESTS)}项工程/CI/架构/安全/性能/a11y/运维发布门禁；
- 测试分为组件、View Model、合同、API集成、浏览器E2E、SIT、独立QA、UAT、发布演练；
- 前端mock只用于组件开发，不得作为SIT/E2E/合同通过证据；
- 关键旅程E2E不得skip，后端和测试数据必须由流水线显式拉起并健康检查；
- P20关键API路径与拒绝路径覆盖门禁不得低于既有0.80口径；Java全局覆盖率如已有更高批准阈值，以更高者为准；
- BLOCKER/MAJOR未清零、契约差异未解释、控制台崩溃、500被错误路径接受、无回滚演练，均阻塞发布。

## 10. 环境与数据

| 环境 | 用途 | 数据 | 禁止 |
|---|---|---|---|
| Local deterministic | 组件、合同、单元、最小集成 | H2/批准fixture | 依赖个人常驻进程、软通过外部依赖 |
| CI | 每次PR门禁 | 可重建固定数据 | skip关键E2E、使用不明共享环境 |
| SIT | 真实适配/权限/队列/回执 | 脱敏或合成、版本化 | 把mock结果当真实联调 |
| UAT | 真实岗位任务 | 业务Owner批准场景 | 使用真实敏感数据而无授权 |
| Staging/Preprod | 性能、安全、发布回滚 | 生产等价规模和配置 | 与生产配置重大漂移 |
| Production | 灰度与运营 | 受控真实数据 | 未批准自动写回、无监控/回滚 |

测试数据必须带版本、生成方式、客户归属、权限角色、清理规则和证据引用；禁止把静态图示例值误作客户事实。

## 11. 团队与职责

| 角色 | 建议投入 | 主要责任 | 不得承担 |
|---|---:|---|---|
| Owner/业务负责人 | 1+ | 范围、业务规则、UAT、发布/冻结决定 | 把静态图直接视为批准合同 |
| Tech Lead | 1 | Loop、架构、追踪、合同候选、跨包协调 | 在同一角色会话直接写Feature实现、自签QA |
| 产品/UX | 1—2 | 44页业务/UX澄清、设计验收、可用性 | 发明权限/状态/授信规则 |
| 前端Feature Pilot | 3—4 | Shell、组件、页面、状态、a11y、测试 | 自行修改合同或绕过门禁 |
| BFF/后端Feature Pilot | 2—3 | View Model、适配、Action/回执、性能 | 先写实现后补合同 |
| QA | 2 | 测试设计、自动化、SIT、缺陷管理 | 把mock冒烟当E2E |
| 独立QA/E2E Owner | 1 | 独立复跑、QA结论 | 为了过测直接改实现 |
| DevOps/SRE | 1 | CI、环境、发布、监控、回滚 | 软通过失败门禁 |
| 安全/合规/数据/业务专家 | 按需 | 权限、隐私、规则、产品边界、数据授权 | 把AI建议当正式决定 |

## 12. 发布、灰度与超护

1. Release Candidate固定提交、镜像、合同哈希、数据迁移版本和前端资产哈希；
2. 灰度优先选择受控用户组，写Action可先保守开启查询/预览，随后按批准条件开放；
3. 监控至少覆盖：页面可用率、P95、API错误、Action失败/重试、Gate阻断、写回回执、草稿冲突、审计缺口和客户端错误；
4. 回滚必须验证旧前端与新后端/数据的兼容，避免只回滚静态资产；
5. 超护期每日复盘关键失败、用户完成率、回滚阈值与未决风险，达到退出条件后转常规运维。

## 13. 关键风险与缓解

| 风险 | 早期信号 | 缓解 | 阻塞门 |
|---|---|---|---|
| 把静态图当业务合同 | 页面先出现新字段/状态 | 强制追踪与C0—C3判定 | G1 |
| 一次性大爆炸重写 | 长分支、无可演示切片 | Shell+垂直切片+Feature Flag | G2/G3 |
| E2E虚绿 | 后端未启动、skip、弱断言 | 可复现环境、执行数断言、关键错误零容忍 | G6 |
| 写回重复或越权 | 重复点击、前端启用按钮 | 服务端权限/幂等/原值校验/回执 | G3B |
| 内外版分叉 | 手工复制删除内容 | 受控投影和版本锁 | G4B |
| 移动缓存泄露 | 撤权后仍可看 | 加密、TTL、设备绑定、远程清除 | G5B |
| 契约基线状态冲突 | 多状态文件含义不一致 | Owner在P0确认唯一权威状态 | G0 |
| 可用性再次下降 | 页面空、层级不清 | V3.2密度基线、任务完成率和业务验收 | G2/G6 |

## 14. 最终Definition of Done

- 44/44目标页有可运行实现，且每页业务逻辑、UX说明、需求、代码、合同、测试可追溯；
- 两条关键旅程在浏览器真实操作并留Trace/截图/日志/回执；
- 所有主动作均有服务端权限/状态/门禁支持；禁用时解释原因与解除路径；
- 契约注册、authority source、generated、SDK、消费者和测试无未解释漂移；
- 候选/事实/AI/人工/审批/写回责任清楚；
- 性能、a11y、安全、移动弱网、幂等、恢复、审计和发布回滚通过；
- 224项V3.2用例及本包新增门禁按适用性执行，关键用例100%通过；
- 独立QA和UAT留有签署；Owner批准发布；
- README、Runbook、迁移/回滚、监控、培训和交接完成；
- 项目状态没有被开发角色夸大为`QA_PASS`、`PRODUCTION_READY`或`FROZEN`。
"""
    write(OUT / '01_GITS_Bank_UX功能重构_全周期交付规划_V1.0.md', main_doc)

    cursor_doc = f"""# Cursor Tech Lead：读取V3.2输入包与受控开工指南

> 目的：告诉Cursor中的Tech Lead如何读、如何建追踪、如何派工、何时停；不授权它直接覆盖项目目录或契约。

## 1. 两个根目录，绝不混放

建议建立同级目录：

```text
<workspace>/gits-knowledge-engineering/          # Git仓库
<workspace>/_reference/gits-bank-v3.2/          # 解压后的只读设计参考
<workspace>/_reference/gits-bank-delivery-plan/ # 本规划包
```

不得把V3.2或本规划包解压到仓库根目录；不得复制覆盖`specs/`、`generated/`、`apps/`、`modules/`、`adapters/`、`frontend/`、`loops/`或`docs/dispatch/`。

先校验：

```bash
sha256sum GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip
# 期望：{v32_sha}
unzip -t GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip
unzip -l GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip
```

Cursor可使用多根工作区：把仓库作为唯一可写根，把两个`_reference`目录作为只读参考根。若无法强制只读，至少在会话规则中声明“参考目录禁止写回仓库”。

## 2. 第一个Cursor会话必须是Tech Lead只读接手

不要一开始要求“按图实现全部页面”。按以下顺序读取：

### 2.1 仓库权威输入

1. `AGENTS.md`
2. `AI_GUIDE.md`
3. `.codebuddy/rules/`中alwaysApply规则，以及将触及路径对应规则
4. `specs/BASELINE_INDEX.yaml`
5. 当前active dispatch和active Loop的`LOOP.yaml`、`STATE.json`、`EVIDENCE.md`
6. `memory/NEXT_SESSION.md`和`ROLE_BOARD.yaml`，确认Baton
7. `specs/CONTRACT_INDEX.yaml`
8. 注册表全部authority source及其consumers/generated
9. 当前前端路由、App Shell、API类型、测试与CI

### 2.2 V3.2参考包

1. `README_交付说明.md`
2. `GITS_Bank_对公客户经营_前端UX与操作需求_V3.2_20260825.md`
3. `GITS_Bank_页面导航与操作逻辑矩阵_V3.2_20260825.md`
4. `GITS_Bank_V3.2_设计系统与组件规范.md`
5. `GITS_Bank_全量功能清单与测试验证用例_V3.2.md`
6. `GITS_DKES_契约保护与兼容性核验_V3.2.md`
7. `界面清单与追踪_V3.2.json`
8. `images/`逐页图；`overviews/`只用于索引

### 2.3 本规划包

先读01—04，再把05—07导入任务/测试管理工具；08只用于发现真实Gap；09用于启动受控会话。

## 3. 开工快照

在仓库根目录只读执行并保存输出：

```bash
git status --short
git branch --show-current
git rev-parse HEAD
sha256sum specs/CONTRACT_INDEX.yaml
python3 - <<'PY'
import hashlib, json, pathlib
p=pathlib.Path('specs/CONTRACT_INDEX.yaml')
d=json.loads(p.read_text())
sources=sorted({{c['authority_source'] for c in d['contracts']}})
assert sources, 'contract registry parsed zero authority sources'
for s in sources:
    f=pathlib.Path(s)
    assert f.is_file(), s
    print(hashlib.sha256(f.read_bytes()).hexdigest(), s)
print('authority_source_count', len(sources))
PY
```

当前参考点是`{repo_branch}@{repo_commit}`、CONTRACT_INDEX `{contract_index_sha}`、{len(unique_sources)}个唯一authority source。Tech Lead必须以实际开工时仓库状态为准，若不同则生成新的差异报告，不能把旧哈希强行“恢复”到仓库。

## 4. Tech Lead的第一份输出，不是代码

必须先产出并由Owner确认：

- 当前Loop/Baton与是否允许创建新Loop；
- 44页→现有路由/组件/API/合同/测试的差距矩阵；
- 每个主动作C0/C1/C2/C3判定；
- Node/CI/E2E/contract-check等开工阻塞修复包；
- P2 Shell和首个垂直切片的派工、门禁、exit criteria；
- 不修改受保护契约的实现方案；
- 未决业务/数据/权限问题及Owner决策点。

没有G1批准，不进入大规模页面编码。

## 5. 新Loop与角色隔离

仅在Owner确认后使用仓库命令创建新Loop；Loop ID以仓库实际序列和命名政策为准。候选示例：

```bash
make new-loop LOOP=P23-gits-bank-ux-foundation HOLDER=tech_lead
```

Tech Lead会话负责架构、追踪、合同候选和派工，不直接混写Feature实现。切换Feature Pilot时重新确认Loop、scope、gate、Baton；切换E2E Owner时确认开发证据齐全，E2E Owner不得改实现来“修绿”。

## 6. 如何从V3.2落到代码

对每页按固定卡片处理：

```text
Page ID / Requirement IDs
→ 业务对象与用户目标
→ 入口/主动作/下一页/返回上下文
→ Query与Command
→ 合同ID / authority source / consumer
→ C0/C1/C2/C3
→ Feature文件与路由
→ Unit/Component/Contract/E2E Test IDs
→ Evidence
```

静态图中的字段、数字、状态、按钮都不是自动授权。没有合同支持时：

- 查询组合：放View Model/BFF；
- 纯展示派生：用显式本地类型/`computed`，不写回；
- 写动作缺失：禁用/只读/降级并说明；
- 关键能力不可实现：建候选Gap并停工，不在前端伪造。

## 7. 契约更新的正确含义

“更新契约”不是让Cursor编辑`generated/`或在前端补字段。只有在批准的需求/Owner决定授权后：

1. 形成`CONTRACT_CHANGE_CANDIDATE`；
2. Contract Owner、GITS/DKES Owner、消费者、安全/合规、独立QA评审；
3. 获批后先改authority source；
4. 更新注册表（新增/版本变化时）；
5. `make generate && make check`；
6. `make contract-diff BASELINE=<受控基线目录>`与`make contract-verify`；
7. 再改SDK、BFF、前端/后端消费者；
8. 执行迁移、双跑/兼容和回滚测试；
9. 独立QA与Owner决定是否进入新基线。

在当前“GITS—DKES契约不能变更”的约束下，C3只形成阻塞与决策材料，不得擅自进入第3步。

## 8. 每个PR必须包含

- Loop ID、Page IDs、Requirement IDs、Contract IDs、Test IDs；
- 变更前后用户行为与截图/视觉差异；
- 四态、权限、异常、返回/恢复、a11y测试；
- 若无契约变更，明确`CONTRACT_CHANGE=NONE`并附检查；
- 若有批准候选，附ADR、兼容/迁移/回滚和消费者测试；
- 显式`git add <paths>`，不得`git add .`；
- 失败先写`FAILURES.md`再修；不得由开发者写`QA_PASS`。

## 9. Cursor必须停止的条件

- Baton不属于当前角色或Loop scope不含目标工作；
- 找不到唯一active dispatch/Loop或权威状态冲突；
- 页面动作需要新正式字段/状态/枚举/权限/Action；
- 受保护authority source发生未批准变化；
- 测试依赖未授权真实数据、密钥或外部系统；
- 需要启用quarantine中的Oracle/Ossie而无ADR和数据Owner授权；
- 关键失败未留证据、或有人要求开发角色自签QA/上线。

## 10. 如何使用本规划包中的表格

- 05 CSV：导入需求/开发工具，一行一个页面；用`phase`和`page_id`建Epic/Feature；不得把`target_route_candidate`当后端合同。
- 06 CSV：导入测试管理工具；先保留`PLANNED`，执行后填build/commit/env/actor/result/evidence/defect。
- 07 CSV：建立里程碑和RACI；每个gate的Approver不能被Implementer代替。
- 08 MD：仅复制为新的候选记录，不覆盖现有合同文件。
- 09 MD：作为Cursor短提示词；仍须由Cursor真实读取仓库，而非相信提示词中的历史状态。
- 10 CSV：拆分为工程看板任务；依赖仅是初始候选，Tech Lead可在不破坏Gate的前提下并行化，但不得把跨Gate依赖删掉。
"""
    write(OUT / '02_Cursor_Tech_Lead_V3.2输入包读取与受控开工指南.md', cursor_doc)

    contract_rows = []
    source_consumers: dict[str, set[str]] = {}
    source_ids: dict[str, list[str]] = {}
    for c in contracts:
        source = c['authority_source']
        source_consumers.setdefault(source, set()).update(c.get('consumers', []))
        source_ids.setdefault(source, []).append(c['id'])
    for source in unique_sources:
        c0 = next(c for c in contracts if c['authority_source'] == source)
        contract_rows.append([
            ', '.join(source_ids[source]), c0['kind'], c0['compatibility'], source,
            sha256(REPO / source), ', '.join(sorted(source_consumers[source]))
        ])
    contract_doc = f"""# GITS—DKES契约读取、候选修订、迁移与回滚规范

> 当前结论：`PROTECTED_CONTRACT_CHANGE=NONE`。  
> 本文定义“如何判断和治理”，不授权实际变更受保护契约。

## 1. 保护范围

`specs/CONTRACT_INDEX.yaml`是唯一契约注册表。当前{len(contracts)}条契约记录指向{len(unique_sources)}个唯一authority source，覆盖OpenAPI、AsyncAPI、语义、规则、Skill、Action、Data/Mapping、Evidence、Evaluation及Knowledge Architecture。

把V3.2解压或把本规划包写入`specs/`，都不构成合法契约更新。

## 2. 当前受保护清单

{md_table(['合同ID','类型','兼容策略','authority source','SHA-256','消费者'], contract_rows)}

## 3. 读契约的顺序

1. 读`BASELINE_INDEX`和Owner决定，确认需求是否批准；
2. 读`CONTRACT_INDEX`确认ID、Owner、兼容策略、消费者与生成物；
3. 读authority source本身；
4. 读生成脚本和`generated/`，只用于理解，不手改；
5. 读前端SDK、BFF/Controller/DTO/Adapter等消费者；
6. 读合同测试、拒绝路径和Loop证据；
7. 把UI事件映射到合同，不从图片反推正式字段。

## 4. Gap判定树

| 问题 | 是 | 否 |
|---|---|---|
| 既有查询/Action已支持？ | C0复用 | 继续判断 |
| 可由多个既有响应组成View Model？ | C1在BFF/前端组合 | 继续判断 |
| 只是排序、筛选、展示标签、图表或PageReference？ | C1纯展示派生，不写回 | 继续判断 |
| 可安全只读/禁用/降级？ | C2并解释原因 | C3关键Gap，停止实现 |

C3不是“让前端临时补字段”的理由，而是提交Owner决策的理由。

## 5. 受保护契约保持不变时的首选实现

- BFF聚合多个既有查询，返回展示中立View Model；如BFF输出本身属于受控接口，仍须按仓库流程注册，不能暗建旁路API；
- TypeScript intersection/派生类型只容纳本地UI字段，并用命名/注释标识`local`/`derived`；
- 路由、工作区标签、筛选、滚动和草稿引用作为PageReference/UI状态；
- 缺少正式写Action时按钮只读或禁用；不把localStorage当事实库；
- G0—G5、F/C/B/H/P/A、权限、审批和写回结果只展示服务端受控状态。

## 6. 候选修订流程

只有批准需求或Owner变更授权后才允许启动：

1. **登记Gap**：场景、页面、角色、业务后果、当前合同、证据；
2. **穷尽零变更方案**：C0/C1/C2评估及为何不足；
3. **形成候选**：ID、Owner、authority source、兼容类型、消费者、数据/安全/审计影响；
4. **ADR与评审**：Contract Owner、GITS Owner、DKES Owner、业务、数据、安全合规、独立QA；
5. **批准后改源**：先authority source，必要时更新`CONTRACT_INDEX`；
6. **生成与差异**：`make generate`、`make check`、`make contract-diff`、`make contract-verify`；
7. **消费者实现**：后端/BFF/SDK/前端按批准版本更新；
8. **迁移/双跑**：数据、事件、规则或状态变更按兼容策略执行；
9. **回滚验证**：代码、数据、事件、缓存、草稿和前端兼容一起验证；
10. **独立QA与Owner门禁**：通过后才可进入基线或发布。

当前用户要求GITS—DKES契约不能变更，因此发现C3时默认结果是`BLOCKED_OR_DESCOPED`，除非Owner另行明确修改该约束。

## 7. 兼容与迁移要求

| 类型 | 兼容要求 | 迁移/回滚重点 |
|---|---|---|
| OpenAPI/AsyncAPI | 新增可选字段/端点优先；删除、重命名、改类型、收紧必填为breaking | 双版本/双读、消费者升级顺序、旧客户端回滚 |
| LinkML/OWL/SHACL | explicit migration | 语义ID、shape验证、投影重建、历史数据解释 |
| DMN | versioned decision | 规则版本、生效时间、复算范围、旧决定可解释 |
| Action/HumanGate | no silent breaking change | 权限、幂等、原值、回执、补偿、审计责任 |
| Data/R2RML | versioned mapping | 源字段血缘、回填、双跑对账、撤销映射 |
| Evidence/Evaluation | backward compatible或显式版本 | 证据引用稳定、运行清单可重放、旧报告可追溯 |
| Knowledge/Activation/Route/Plan | 按注册表策略 | 路由歧义、技能选择、计划重放、shadow验证 |

## 8. 禁止操作

- 直接覆盖`specs/CONTRACT_INDEX.yaml`或authority source；
- 手工编辑`generated/`；
- 先改Controller/DTO/TypeScript再补合同；
- 在前端新增正式枚举、状态机或权限判断；
- 用V3.2示例字段/状态替代受控合同；
- 未评估消费者就改变共享Schema；
- 未执行拒绝路径、迁移和回滚测试就宣称兼容；
- 将`DESIGN_CANDIDATE`标成已批准基线。

## 9. 候选门禁

| Gate | 必须满足 | 失败结果 |
|---|---|---|
| CC0 Gap有效 | 需求已批准；有证据；C0—C2不足 | 退回分析 |
| CC1 设计可审 | 兼容、消费者、安全、数据、迁移、回滚完整 | 不得改源 |
| CC2 Owner批准 | 合同Owner与业务/系统Owner书面批准 | 保持C2降级 |
| CC3 源与生成一致 | authority source→generate→check通过 | 阻塞实现 |
| CC4 消费者兼容 | 合同/API/SDK/集成/拒绝路径通过 | 不得联调 |
| CC5 独立QA | 迁移、回滚、E2E证据齐全 | 不得发布 |

模板见`08_CONTRACT_CHANGE_CANDIDATE_模板.md`。
"""
    write(OUT / '03_GITS_DKES_契约读取_候选修订_迁移回滚规范.md', contract_doc)

    test_doc = f"""# GITS Bank 测试策略与验证用例集 V1.0

> 本文把V3.2的224项计划用例放进工程阶段与发布门禁，并新增{len(EXTRA_TESTS)}项当前仓库专项用例。  
> 所有用例初始状态为`PLANNED`；本文件不宣称任何用例已执行。

## 1. 测试目标

测试必须证明“银行岗位能完成任务且责任边界不被AI/前端越过”，而不只是DOM有文字：

- 页面业务逻辑、入口、主动作、下一步和返回上下文正确；
- UI、BFF、API、合同、权限、证据、Action、Gate、回执和审计连续；
- 候选与正式事实分离，Need先于产品，审批/授信/定价责任不被AI继承；
- 弱网、超时、重复提交、版本冲突、撤权、降级和回滚不丢数据、不越权；
- V3.2视觉密度、左导航、工作区标签和清爽配色能在真实内容下保持可读。

## 2. 用例规模

| 来源 | 数量 | 构成 |
|---|---:|---|
| V3.2逐页 | 176 | 44页×正常/权限/异常/恢复4类 |
| V3.2专项 | 48 | 12 E2E + 12契约 + 24质量 |
| 本规划新增 | {len(EXTRA_TESTS)} | 工程基线、CI、架构、合同、安全、性能、a11y、运维发布 |
| 合计 | {224 + len(EXTRA_TESTS)} | 详见06 CSV |

## 3. 测试层次与责任

| 层次 | 主要对象 | 最低自动化 | 责任 | 证据 |
|---|---|---|---|---|
| Static/Type | TS、路由、依赖、合同引用 | 每PR | Feature Pilot | lint/type/diff |
| Unit | Composable、Store、View Model、规则适配 | 每PR | Feature Pilot | 覆盖率/JUnit |
| Component | 四态、权限、键盘、视觉组件 | 每PR | 前端+QA | Vitest/截图 |
| Contract | 21 authority sources、SDK/DTO/consumer | 每PR | Integration Owner | hash/diff/negative test |
| API Integration | H2/真实适配、拒绝路径、幂等 | 每PR/每日 | 后端+QA | HTTP/DB/trace |
| Browser E2E | 两条旅程、44页冒烟、恢复 | 每PR关键集/每日全量 | E2E Owner | Playwright trace/video |
| SIT | 真实系统联调 | 每RC | QA | SIT报告 |
| Independent QA | 独立复跑关键集 | 每RC | 独立QA | QA attestation |
| UAT | 真实岗位任务 | 发布前 | 业务Owner | UAT签署 |
| Release/DR | 灰度、回滚、监控 | 发布前/演练 | SRE+Owner | Runbook/日志 |

## 4. 阶段执行波次

| 阶段 | 必跑集合 | 出口标准 |
|---|---|---|
| P0/P1 | ENG、CI、CTR基础负测 | 环境/注册表/执行数门禁真实有效 |
| P2 | 01—03 + ARC/A11Y/PERF底座 | Shell、组件、四态、键盘、视觉基线通过 |
| P3 | 04—10 + 权限/图谱/列表专项 | 客户与信号切片通过 |
| P4 | 11—19 + E2E-01 + 幂等/恢复 | 持续经营闭环通过 |
| P5 | 20—22、36 + Need边界 | Need→计划→任务连续 |
| P6 | 23—30 + E2E-02/06/07/08 | 建议书闭环通过 |
| P7 | 31—40 + 审批/交付/治理/恢复 | 桌面全功能候选通过 |
| P8 | 41—44 + E2E-04/05 | 移动弱网/撤权/冲突通过 |
| P9 | 224原始+新增适用用例全量 | BLOCKER/MAJOR=0，关键100% |
| P10 | OPS、UAT、回滚、灰度 | Owner批准后发布 |

## 5. 关键E2E数据链断言

### 5.1 持续经营

每步断言`customerId/accountId`、`signalId`、`engagementId/journeyId`、Claim/Evidence引用、操作者、时间、版本和Trace连续。离场前内容仍是客户陈述/待核实；CRM写回必须有差异、确认、幂等和回执。

### 5.2 建议书

每步断言Customer→Need→Service Plan→Proposal→Version→Expert Opinion→Gate Decision→Customer Projection→Delivery Receipt→Account Plan可追溯。产品候选必须反查Need；客户版必须由内部版受控投影；审批中版本不可直接覆盖。

## 6. CI必须整改并验证

1. CI Node改为22+并与`frontend/package.json`、bootstrap一致；
2. 契约检查必须解析`authority_source`，断言检查数量非零；
3. Playwright流水线显式启动后端、前端和测试数据，先健康检查；
4. 输出机器可读Playwright/JUnit结果，关键用例0 skip；
5. 关键控制台错误/页面崩溃零容忍；
6. 不存在对象返回受控4xx/错误Schema，500不算合格；
7. 失败先留证据，不得用`|| true`、警告转成功或测试条件绕过；
8. `make verify`按确定性本地门禁与需外部凭据的环境门禁分层记录。

## 7. 性能、可访问性与安全阈值

- 核心内容P95≤3秒；测量起止、并发、数据量、网络和服务端时间必须固定；
- 大列表虚拟化、大图谱渐进加载，会中长时间录入无数据丢失或内存失控；
- WCAG 2.1 AA、键盘完成两条关键旅程、200%缩放、关系图表格等价；
- 客户范围、字段级权限、用途限制、导出、审批职责分离、审计不可改；
- 移动缓存加密、TTL、设备绑定、撤权/远程清除；
- 埋点、日志、Trace和错误上报不得含未脱敏客户正文。

## 8. 缺陷与通过规则

| 等级 | 例子 | 发布规则 |
|---|---|---|
| BLOCKER | 越权、正式数据错写、不可回滚、关键旅程不可用 | 0 |
| MAJOR | 主动作失败、证据/审批断链、数据丢失、核心a11y阻断 | 0 |
| MINOR | 非关键排版、可绕行体验问题 | 有Owner接受和期限 |
| COSMETIC | 不影响任务的细微视觉差 | 可进入后续优化 |

任何“未执行”“环境不具备”“只用mock”都不能记为PASS；应记`NOT_RUN`、`BLOCKED`或`NOT_APPLICABLE_WITH_APPROVAL`。

## 9. 每条用例证据字段

`test_id, requirement_id, page_id, contract_id, build, commit, environment, actor_role, test_data_version, started_at, actual_result, status, screenshot_or_trace, log_or_receipt, defect_id, reviewer`。

06 CSV已经给出计划字段；实际执行结果必须写入项目批准的测试/Loop证据位置，不要回写本参考包冒充执行记录。
"""
    write(OUT / '04_GITS_Bank_测试策略与验证用例集_V1.0.md', test_doc)

    # Page traceability matrix.
    trace_rows = []
    for s in screens:
        no = int(s['no'])
        reqs = ';'.join(f'UX-FR-{no:02d}-{i:02d}' for i in range(1, 6))
        tests = ';'.join(f'TC-P{no:02d}-{i:02d}' for i in range(1, 5))
        trace_rows.append({
            'page_id': f'P{no:02d}', 'page_title': s['title'], 'journey': s['journey'],
            'phase': phase_for(no), 'current_repo_route': CURRENT_ROUTE.get(no, 'NONE'),
            'target_route_candidate': ROUTES[no], 'primary_actions': ' / '.join(s['actions']),
            'next_step': s['next_step'], 'business_rule': s['business_rule'],
            'contract_mode': s['contract_usage'].split('：')[0],
            'contract_decision': 'P1逐动作映射；无支持则C2降级，禁止前端造字段',
            'requirement_ids': reqs, 'test_ids': tests,
            'implementation_status': 'NOT_STARTED', 'evidence_status': 'NOT_RUN',
        })
    trace_fields = ['page_id','page_title','journey','phase','current_repo_route','target_route_candidate','primary_actions','next_step','business_rule','contract_mode','contract_decision','requirement_ids','test_ids','implementation_status','evidence_status']
    csv_write(OUT / '05_GITS_Bank_页面_阶段_契约_测试追踪矩阵.csv', trace_rows, trace_fields)

    # Parse 224 V3.2 tests.
    original_text = (V32_ROOT / 'GITS_Bank_全量功能清单与测试验证用例_V3.2.md').read_text(encoding='utf-8')
    test_rows: list[dict] = []
    screen_by_no = {int(s['no']): s for s in screens}
    for m in re.finditer(r'^- `(?P<id>TC-P(?P<page>\d+)-\d+)` (?P<body>.+)$', original_text, re.M):
        page_no = int(m.group('page'))
        body = m.group('body')
        if '步骤—' in body and '；预期—' in body:
            label, rest = body.split('：步骤—', 1)
            steps, expected = rest.split('；预期—', 1)
        else:
            label, steps, expected = '页面验证', body, '满足V3.2页面验收标准'
        test_rows.append({
            'test_id': m.group('id'), 'source': 'V3.2', 'category': label,
            'page_id': f'P{page_no:02d}', 'page_title': screen_by_no[page_no]['title'],
            'phase': phase_for(page_no), 'gate': phase_for(page_no).split('-')[0],
            'precondition': screen_by_no[page_no]['precondition'], 'steps': steps,
            'expected': expected.rstrip('。'), 'priority': 'P0' if page_no in {1,4,11,15,18,19,21,25,26,27,32,33,34,41,42,43,44} else 'P1',
            'automation': 'PLAYWRIGHT_OR_COMPONENT', 'evidence_required': '截图/trace/API与控制台日志',
            'status': 'PLANNED', 'actual_result': '', 'evidence_link': '', 'defect_id': '',
        })
    for line in original_text.splitlines():
        if not line.startswith('| TC-'):
            continue
        parts = [x.strip() for x in line.strip().strip('|').split('|')]
        if len(parts) != 4:
            continue
        tid, category, scenario, expected = parts
        test_rows.append({
            'test_id': tid, 'source': 'V3.2', 'category': category, 'page_id': '', 'page_title': '',
            'phase': 'P9-全量验证', 'gate': 'P9/G6', 'precondition': '相应功能候选已部署到受控测试环境',
            'steps': scenario, 'expected': expected, 'priority': 'P0' if category in {'端到端','契约'} else 'P1',
            'automation': 'E2E/CONTRACT/SPECIALIZED', 'evidence_required': '命令、日志、trace、截图或回执',
            'status': 'PLANNED', 'actual_result': '', 'evidence_link': '', 'defect_id': '',
        })
    for tid, cat, title, scenario, expected, phase, gate, evidence in EXTRA_TESTS:
        test_rows.append({
            'test_id': tid, 'source': 'V1.0施工规划', 'category': cat, 'page_id': '', 'page_title': '',
            'phase': phase, 'gate': gate, 'precondition': '对应阶段输入与环境已准备',
            'steps': f'{title}：{scenario}', 'expected': expected, 'priority': 'P0',
            'automation': 'AUTOMATE_WHERE_PRACTICAL', 'evidence_required': evidence,
            'status': 'PLANNED', 'actual_result': '', 'evidence_link': '', 'defect_id': '',
        })
    test_fields = ['test_id','source','category','page_id','page_title','phase','gate','precondition','steps','expected','priority','automation','evidence_required','status','actual_result','evidence_link','defect_id']
    csv_write(OUT / '06_GITS_Bank_测试用例执行矩阵.csv', test_rows, test_fields)

    # Milestones/RACI.
    raci_rows = []
    for p in PHASES:
        responsible = {
            'P0':'Tech Lead','P1':'Tech Lead / Integration Owner','P2':'Frontend Feature Pilot',
            'P3':'Frontend+BFF Feature Pilots','P4':'Frontend+BFF+Backend Feature Pilots',
            'P5':'Product SME+Feature Pilots','P6':'Proposal Feature Pilots',
            'P7':'Feature Pilots+Governance Owners','P8':'Mobile/Frontend+Security',
            'P9':'QA / E2E Owner','P10':'Release Owner / SRE'
        }[p['id']]
        approver = 'Owner / Tech Lead' if p['id'] in {'P0','P1','P2'} else ('Independent QA / Owner' if p['id']=='P9' else ('Owner / Release CAB' if p['id']=='P10' else 'Tech Lead / Business Owner'))
        raci_rows.append({
            'phase': p['id'], 'reference_window': p['window'], 'milestone': p['name'],
            'task_summary': p['tasks'], 'deliverables': p['outputs'], 'exit_gate': p['gate'],
            'responsible_R': responsible, 'accountable_A': approver,
            'consulted_C': 'Product/UX, Contract Owners, Security/Compliance, Data Owner',
            'informed_I': 'PMO, Operations, affected consumers', 'status': 'PLANNED',
        })
    raci_fields = ['phase','reference_window','milestone','task_summary','deliverables','exit_gate','responsible_R','accountable_A','consulted_C','informed_I','status']
    csv_write(OUT / '07_阶段门禁_交付物_RACI_里程碑矩阵.csv', raci_rows, raci_fields)

    # Detailed WBS for direct execution planning.
    wbs_rows = []
    previous_phase = ''
    for phase in [p['id'] for p in PHASES]:
        tasks = WBS[phase]
        for idx, (stream, task, output, acceptance) in enumerate(tasks, 1):
            task_id = f'{phase}-T{idx:02d}'
            if idx > 1:
                dependency = f'{phase}-T{idx-1:02d}（可由Tech Lead按并行性放宽）'
            elif previous_phase:
                dependency = f'{previous_phase}出口门禁'
            else:
                dependency = 'Owner开工授权与输入可用'
            owner = {
                'P0':'Tech Lead','P1':'Tech Lead / Integration Owner','P2':'Frontend Feature Pilot',
                'P3':'Frontend+BFF Feature Pilots','P4':'Frontend+BFF+Backend Feature Pilots',
                'P5':'Product SME+Feature Pilots','P6':'Proposal Feature Pilots',
                'P7':'Feature Pilots+Governance Owners','P8':'Mobile/Frontend+Security',
                'P9':'QA / E2E Owner','P10':'Release Owner / SRE'
            }[phase]
            wbs_rows.append({
                'task_id': task_id, 'phase': phase, 'workstream': stream, 'task': task,
                'dependency': dependency, 'responsible': owner, 'output': output,
                'acceptance': acceptance,
                'contract_rule': 'C0/C1优先；C2降级；C3停工候选；禁止手改generated',
                'test_or_gate': next(p['gate'] for p in PHASES if p['id'] == phase),
                'evidence_required': 'Loop ID、commit、环境、命令/日志/截图/回执、reviewer',
                'status': 'PLANNED', 'actual_owner': '', 'start': '', 'finish': '', 'evidence_link': '',
            })
        previous_phase = phase
    wbs_fields = ['task_id','phase','workstream','task','dependency','responsible','output','acceptance','contract_rule','test_or_gate','evidence_required','status','actual_owner','start','finish','evidence_link']
    csv_write(OUT / '10_工程WBS与验收任务清单.csv', wbs_rows, wbs_fields)

    candidate_template = """# CONTRACT_CHANGE_CANDIDATE 模板

> 仅复制为新的候选记录使用。不要覆盖现有authority source、`CONTRACT_INDEX.yaml`或`generated/`。  
> 当前GITS Bank UX重构默认不允许改变GITS—DKES受保护契约；无Owner授权时状态必须保持`BLOCKED_OR_DESCOPED`。

## A. 标识与状态

| 字段 | 内容 |
|---|---|
| Candidate ID | CCC-GITS-BANK-YYYYMMDD-NNN |
| Loop ID / Baton | |
| 发起人/角色 | |
| 状态 | DRAFT / REVIEW / OWNER_APPROVED / REJECTED / WITHDRAWN |
| 关联需求/Owner决定 | |
| 关联页面/动作 | |
| 现有Contract IDs | |
| authority source | |
| Contract Owner / GITS Owner / DKES Owner | |

## B. 业务Gap

- 用户角色与任务：
- 触发与前置：
- 当前可观察行为：
- 期望行为：
- 不解决的业务后果：
- 证据与复现：

## C. 零变更方案评估

| 方案 | 可行性 | 风险 | 结论 |
|---|---|---|---|
| C0复用现有契约 | | | |
| C1 BFF/View Model组合 | | | |
| C1纯展示派生 | | | |
| C2只读/禁用/降级 | | | |

## D. 候选变更

- 变更类型：新增可选字段 / 新端点 / 新事件 / 版本化规则 / 映射 / 其它
- Before / After：
- 语义、状态、权限和责任是否变化：
- 是否breaking：
- 兼容策略：
- 生效/废止时间：
- 数据分类、隐私与审计：

## E. 消费者影响

| Consumer | 当前版本 | 目标版本 | 变更 | Owner | 测试 | 上线顺序 |
|---|---|---|---|---|---|---|
| | | | | | | |

## F. 迁移、双跑与回滚

- 数据迁移与对账：
- 双读/双写/版本协商：
- 事件重放/去重：
- 缓存、草稿与前端兼容：
- 回滚触发阈值：
- 回滚步骤与预计影响：
- 不可逆部分及Owner接受：

## G. 验证

- `make generate`：
- `make check`：
- `make contract-diff BASELINE=...`：
- `make contract-verify`：
- consumer tests：
- rejection paths：
- migration/rollback rehearsal：
- independent QA：

## H. 决策签署

| 角色 | 姓名 | 决定 | 日期 | 证据 |
|---|---|---|---|---|
| Contract Owner | | | | |
| GITS Owner | | | | |
| DKES Owner | | | | |
| Business Owner | | | | |
| Security/Compliance | | | | |
| Data Owner | | | | |
| Independent QA | | | | |

未完成签署前：`AUTHORITY_SOURCE_CHANGE=NO`、`IMPLEMENTATION_DEPENDENCY=NO`。
"""
    write(OUT / '08_CONTRACT_CHANGE_CANDIDATE_模板.md', candidate_template)

    prompt_doc = f"""# Cursor Tech Lead 开工提示词

## 提示词A：只读接手与规划（先用这个）

```text
你是本仓库的Tech Lead。当前只做只读接手、差距分析、Loop规划与合同映射，不写Feature代码，不修改任何仓库文件。

必须按仓库AGENTS.md和AI_GUIDE.md执行。先读取BASELINE_INDEX、当前active dispatch/Loop/STATE/EVIDENCE/NEXT_SESSION/ROLE_BOARD并确认Baton，再读CONTRACT_INDEX及全部authority_source、消费者和测试。记录branch、commit、clean status、CONTRACT_INDEX SHA和authority_source数量；解析数量为0必须失败。

然后读取只读参考包：
1) /飞-银行对公知识工程与岗位智能体/GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip 解压后的文档；ZIP期望SHA-256={v32_sha}
2) GITS Bank全周期施工与最终交付规划包01—09文档。

不要把任何参考包解压/复制覆盖到仓库。V3.2是DESIGN_CANDIDATE，不是specs或generated的替换源。GITS—DKES受保护契约默认NO_CHANGE。

输出：
- 当前权威状态与Baton结论；
- 44页→当前路由/组件/API/合同/测试差距矩阵；
- 每个主动作C0复用/C1组合派生/C2降级/C3阻塞判定；
- Node、CI、contract-check、Playwright环境与弱断言的开工阻塞；
- P0/P1/P2和首个垂直切片的Loop、gates、exit criteria、RACI；
- 需Owner决策的问题。

任何新正式字段/状态/枚举/权限/Action都必须停下并建立CONTRACT_CHANGE_CANDIDATE；未批准不得改authority source，更不得手改generated。不要写QA_PASS、PRODUCTION_READY或FROZEN。
```

## 提示词B：Tech Lead创建首个Loop（Owner确认后）

```text
你仍是Tech Lead，只做Loop/架构/追踪/派工，不写Feature实现。重新确认active Loop、Baton、仓库clean status和合同哈希。根据Owner批准的范围，用仓库make new-loop创建一个最小Loop；Loop ID按当前仓库序列确定，不盲用历史示例。

首Loop只包括：CI/环境门禁修复、Experience Shell、V3.2设计Token、左导航、工作区标签、对象头、PageReference、四态/权限/错误组件，以及页面01—03最小真实切片。为每项绑定Page ID、Requirement IDs、Contract IDs或C1/C2判定、Test IDs和退出证据。

如果需要GITS—DKES契约变更，停止并提交候选，不得在该Loop中静默吸收。
```

## 提示词C：Feature Pilot实现（角色切换后单独会话）

```text
[切换到Feature Pilot模式]
读取当前Loop全部共享记忆并确认Baton。只实现LOOP.yaml授权scope；TDD，先合同/组件/拒绝路径测试，再实现。前端使用Vue3 script setup、具体类型、四态、批准的UI库策略和既有API客户端；本地派生字段显式隔离，禁止any/@ts-ignore/正式状态硬编码。

失败先写FAILURES.md再修；每个Gate更新STATE/EVIDENCE；显式git add路径，禁止git add .。完成只能记录DEV_SELF_CHECK_PASS并交给独立E2E Owner，不得自签QA_PASS。
```

## 提示词D：独立E2E/QA（开发交棒后）

```text
[切换到E2E Owner模式]
确认开发Gate和证据齐全，不修改实现。启动真实后端、前端和版本化测试数据；健康检查通过后执行合同、API、浏览器E2E、权限、异常、幂等、恢复、性能和a11y。关键E2E不得skip，控制台崩溃零容忍，500不得当作预期错误成功。

对失败先记录证据并退回Feature Pilot；全部出口标准满足后才由独立QA记录QA_PASS。UAT、RELEASE_APPROVED、PRODUCTION_READY、FROZEN仍由相应Owner/门禁决定。
```
"""
    write(OUT / '09_Cursor_Tech_Lead_开工提示词.md', prompt_doc)

    # Evidence snapshots; do not mutate repo.
    contract_snapshot_lines = [
        f'repository_commit\t{repo_commit}', f'repository_branch\t{repo_branch}',
        f'repository_clean\t{str(not bool(repo_status)).lower()}', f'contract_index_sha256\t{contract_index_sha}',
        f'contract_record_count\t{len(contracts)}', f'unique_authority_source_count\t{len(unique_sources)}',
        '', '# sha256\tauthority_source\tcontract_ids'
    ]
    for source in unique_sources:
        contract_snapshot_lines.append(f'{sha256(REPO/source)}\t{source}\t{",".join(source_ids[source])}')
    write(OUT / 'evidence/当前仓库与受保护契约快照.tsv', '\n'.join(contract_snapshot_lines))
    write(OUT / 'evidence/V3.2输入包校验.txt', f"filename={V32_ZIP.name}\nsha256={v32_sha}\nsize_bytes={V32_ZIP.stat().st_size}\nsource_library_path=/飞-银行对公知识工程与岗位智能体/{V32_ZIP.name}\nstatus=DESIGN_CANDIDATE\n")
    current_snapshot = f"""repository={REPO}
branch={repo_branch}
commit={repo_commit}
git_status_porcelain={'CLEAN' if not repo_status else repo_status}
frontend_route_count=10
target_screen_count=44
current_navigation=HORIZONTAL_MENU
target_navigation=LEFT_PANEL_WITH_WORKSPACE_TABS
frontend_node_engine=>=22
ci_node_version=20
contract_index_field=authority_source
ci_contract_check_pattern=path:
playwright_webserver=FRONTEND_ONLY
v32_zip_sha256={v32_sha}
planning_status=PLANNING_CANDIDATE
implementation_status=NOT_EXECUTED
"""
    write(OUT / 'evidence/当前工程入口与已知门禁差距.txt', current_snapshot)

    # Manifest before checksums.
    manifest = {
        'package': PACKAGE_NAME,
        'version': 'V1.0', 'date': '2026-08-25', 'status': 'PLANNING_CANDIDATE',
        'source_v32_zip': V32_ZIP.name, 'source_v32_sha256': v32_sha,
        'repository_branch': repo_branch, 'repository_commit': repo_commit,
        'repository_clean_before': not bool(repo_status), 'contract_index_sha256': contract_index_sha,
        'contract_records': len(contracts), 'unique_authority_sources': len(unique_sources),
        'target_screens': len(screens), 'phases': len(PHASES), 'engineering_wbs_tasks': len(wbs_rows),
        'v32_planned_tests_imported': len([r for r in test_rows if r['source']=='V3.2']),
        'additional_gate_tests': len(EXTRA_TESTS), 'total_planned_tests': len(test_rows),
        'contract_change_authorized': False, 'repo_files_modified': False,
    }
    write(OUT / 'deliverable_manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))

    # Copy source script for reproducibility.
    (OUT / 'sources').mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__), OUT / 'sources/build_gits_bank_delivery_plan.py')

    # Quality checks.
    errors = []
    warnings = []
    if len(screens) != 44:
        errors.append(f'screen count={len(screens)}')
    imported = len([r for r in test_rows if r['source'] == 'V3.2'])
    if imported != 224:
        errors.append(f'imported V3.2 tests={imported}, expected=224')
    if len(unique_sources) != 21:
        warnings.append(f'unique authority sources now {len(unique_sources)}; prior V3.2 baseline was 21')
    if repo_status:
        errors.append('repository was dirty before package build')
    if OUT.is_relative_to(REPO):
        errors.append('output directory is inside repository')
    ids = [r['test_id'] for r in test_rows]
    dup = [k for k,v in Counter(ids).items() if v > 1]
    if dup:
        errors.append('duplicate test IDs: ' + ','.join(dup))
    required = [
        '00_README_使用说明.md','01_GITS_Bank_UX功能重构_全周期交付规划_V1.0.md',
        '02_Cursor_Tech_Lead_V3.2输入包读取与受控开工指南.md',
        '03_GITS_DKES_契约读取_候选修订_迁移回滚规范.md',
        '04_GITS_Bank_测试策略与验证用例集_V1.0.md',
        '05_GITS_Bank_页面_阶段_契约_测试追踪矩阵.csv',
        '06_GITS_Bank_测试用例执行矩阵.csv','07_阶段门禁_交付物_RACI_里程碑矩阵.csv',
        '08_CONTRACT_CHANGE_CANDIDATE_模板.md','09_Cursor_Tech_Lead_开工提示词.md',
        '10_工程WBS与验收任务清单.csv',
    ]
    for name in required:
        if not (OUT / name).is_file():
            errors.append(f'missing {name}')
    qa = f"""# QUALITY REPORT

> 结论：`{'PASS' if not errors else 'FAIL'}`  
> 这是规划包结构与一致性检查，不是实现、SIT、独立QA、UAT或生产验收。

## 检查结果

| 检查项 | 结果 |
|---|---|
| 指定V3.2 ZIP SHA校验 | PASS · `{v32_sha}` |
| 目标页面追踪 | {len(trace_rows)}/44 |
| V3.2原始用例导入 | {imported}/224 |
| 新增工程发布门禁用例 | {len(EXTRA_TESTS)} |
| 工程WBS任务 | {len(wbs_rows)} |
| 测试ID唯一性 | {'PASS' if not dup else 'FAIL'} |
| 受保护authority source | {len(unique_sources)} |
| 仓库工作区构建前 | {'CLEAN' if not repo_status else 'DIRTY'} |
| 输出目录位于仓库外 | {'PASS' if not OUT.is_relative_to(REPO) else 'FAIL'} |
| 是否修改仓库/契约 | NO |

## 错误

{('- 无' if not errors else chr(10).join('- ' + x for x in errors))}

## 警告

{('- 无' if not warnings else chr(10).join('- ' + x for x in warnings))}

## 明确未执行

- 未实现44页；未执行真实构建、SIT、独立QA、UAT、性能、渗透或发布；
- 所有测试状态仍为`PLANNED`；
- 未创建新Loop、未改变Baton、未修改`specs/`、`generated/`或源代码；
- 未授权GITS—DKES契约变更；候选模板不等于批准。
"""
    write(OUT / 'QUALITY_REPORT.md', qa)

    if errors:
        raise SystemExit('quality errors: ' + '; '.join(errors))

    # Checksums and ZIP.
    files = sorted(p for p in OUT.rglob('*') if p.is_file() and p.name != 'SHA256SUMS.txt')
    sums = '\n'.join(f'{sha256(p)}  {p.relative_to(OUT).as_posix()}' for p in files)
    write(OUT / 'SHA256SUMS.txt', sums)
    zip_path = OUT_PARENT / f'{PACKAGE_NAME}.zip'
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():
                zf.write(p, arcname=f'{PACKAGE_NAME}/{p.relative_to(OUT).as_posix()}')
    print(json.dumps({
        'out': str(OUT), 'zip': str(zip_path), 'zip_sha256': sha256(zip_path),
        'files': len([p for p in OUT.rglob('*') if p.is_file()]),
        'screens': len(trace_rows), 'v32_tests': imported, 'extra_tests': len(EXTRA_TESTS),
        'total_tests': len(test_rows), 'contracts': len(contracts), 'sources': len(unique_sources),
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
