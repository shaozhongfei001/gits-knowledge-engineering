# CONTRACT_CHANGE_CANDIDATE 模板

> 仅复制为新的候选记录使用。不要覆盖现有authority source、`CONTRACT_INDEX.yaml`或`generated/`。  
> 当前GITS Bank UX重构默认不允许改变GITS—DKES受保护契约；无Owner授权时状态必须保持`BLOCKED_OR_DESCOPED`。

## A. 标识与状态

| 字段 | 内容 |
|---|---|
| Candidate ID | CCC-GITS-BANK-YYYYMMDD-NNN |
| Loop ID / Baton | |
| 发起人/角色 | |
| 状态 | DRAFT / REVIEW / OWNER_APPROVED / REJECTED / WITHDRAWN |
| 关联需求/Owner决定 | |
| 关联页面/动作 | |
| 现有Contract IDs | |
| authority source | |
| Contract Owner / GITS Owner / DKES Owner | |

## B. 业务Gap

- 用户角色与任务：
- 触发与前置：
- 当前可观察行为：
- 期望行为：
- 不解决的业务后果：
- 证据与复现：

## C. 零变更方案评估

| 方案 | 可行性 | 风险 | 结论 |
|---|---|---|---|
| C0复用现有契约 | | | |
| C1 BFF/View Model组合 | | | |
| C1纯展示派生 | | | |
| C2只读/禁用/降级 | | | |

## D. 候选变更

- 变更类型：新增可选字段 / 新端点 / 新事件 / 版本化规则 / 映射 / 其它
- Before / After：
- 语义、状态、权限和责任是否变化：
- 是否breaking：
- 兼容策略：
- 生效/废止时间：
- 数据分类、隐私与审计：

## E. 消费者影响

| Consumer | 当前版本 | 目标版本 | 变更 | Owner | 测试 | 上线顺序 |
|---|---|---|---|---|---|---|
| | | | | | | |

## F. 迁移、双跑与回滚

- 数据迁移与对账：
- 双读/双写/版本协商：
- 事件重放/去重：
- 缓存、草稿与前端兼容：
- 回滚触发阈值：
- 回滚步骤与预计影响：
- 不可逆部分及Owner接受：

## G. 验证

- `make generate`：
- `make check`：
- `make contract-diff BASELINE=...`：
- `make contract-verify`：
- consumer tests：
- rejection paths：
- migration/rollback rehearsal：
- independent QA：

## H. 决策签署

| 角色 | 姓名 | 决定 | 日期 | 证据 |
|---|---|---|---|---|
| Contract Owner | | | | |
| GITS Owner | | | | |
| DKES Owner | | | | |
| Business Owner | | | | |
| Security/Compliance | | | | |
| Data Owner | | | | |
| Independent QA | | | | |

未完成签署前：`AUTHORITY_SOURCE_CHANGE=NO`、`IMPLEMENTATION_DEPENDENCY=NO`。
