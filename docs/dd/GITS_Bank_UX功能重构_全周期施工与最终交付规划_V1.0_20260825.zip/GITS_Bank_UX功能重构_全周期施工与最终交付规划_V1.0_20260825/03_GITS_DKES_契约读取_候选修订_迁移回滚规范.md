# GITS—DKES契约读取、候选修订、迁移与回滚规范

> 当前结论：`PROTECTED_CONTRACT_CHANGE=NONE`。  
> 本文定义“如何判断和治理”，不授权实际变更受保护契约。

## 1. 保护范围

`specs/CONTRACT_INDEX.yaml`是唯一契约注册表。当前25条契约记录指向21个唯一authority source，覆盖OpenAPI、AsyncAPI、语义、规则、Skill、Action、Data/Mapping、Evidence、Evaluation及Knowledge Architecture。

把V3.2解压或把本规划包写入`specs/`，都不构成合法契约更新。

## 2. 当前受保护清单

| 合同ID | 类型 | 兼容策略 | authority source | SHA-256 | 消费者 |
| --- | --- | --- | --- | --- | --- |
| CTR-ACTION-001 | json_schema | no_silent_breaking_change | specs/actions/controlled-action.schema.json | 650df57e991234d0e7e903aa3fa2674c9bf8f65b3d9b067cf42b5c1e1290b00b | external_system_adapters, human_action |
| CTR-MAP-001 | turtle | versioned_mapping | specs/data/customer-source-mapping.r2rml.ttl | f873a85266b45c9ee6aa77ccf04288f26da731485a6fe6fea381fd17f11e784a | oracle_mapping_spike, semantic_runtime |
| CTR-DATA-004 | seed_claims | versioned_mapping | specs/data/oracle-seed-claims.v0.1.json | 201a6e1b0a30a148c268b930d194925d067b8d55fc719e9da04ca8379e95b788 | operational_ontology, semantic_runtime |
| CTR-DATA-001 | json_schema | versioned_mapping | specs/data/source-contract.schema.json | a3079c8ef7855dcc5be085f3e9e9545d19bdb28c62ca28e30c9c24874c4f5bc5 | oracle_mapping_spike, semantic_runtime, source_contract_instances |
| CTR-DATA-002 | source_contract_instance | versioned_mapping | specs/data/src-edwcrm-cust-base.v0.1.json | 66663cb6f38d977419cfdfe878c6e9f1f244a710de11809ec1d29778b5d1a732 | ctr_map_001, oracle_mapping_spike, semantic_runtime |
| CTR-DATA-003 | source_contract_instance | versioned_mapping | specs/data/src-oracle-metric-ontology.v0.1.json | 8ece8c9ab2c80e2782673337c90c073950a1ff071a1121edaad4a01d6391e9e3 | operational_ontology, oracle_mapping_spike, semantic_runtime |
| CTR-EVAL-001 | json_schema | backward_compatible | specs/evaluation/run-manifest.schema.json | 0801cbf4f855cf54b063f2b0434006e7f2a1959181180f77f1709201b4e01545 | evaluation, release_gate |
| CTR-EVENT-001 | asyncapi | backward_compatible | specs/events/domain-events.asyncapi.json | 7ebe61944db6bc1a51604223711d8ab080b7a633b22a93740b125bc189f34158 | api_app, worker_app |
| CTR-EVIDENCE-001 | json_schema | backward_compatible | specs/evidence/evidence-bundle.schema.json | c7cf15255d0dcbef24aed8f94e11cb33528a2e0718eb9f9674a1841266b85242 | context_evidence, evaluation, scenario_services |
| CTR-ACTIVATION-001 | json_schema | explicit_migration | specs/knowledge-architecture/schemas/activation-contract.schema.json | cdb6d1d55f18eb534c2eafb07ef0b9ccc5ebb1bf56cb159b2383eb1e16670889 | activation_planner, agent_orchestrator, skill_runtime |
| CTR-PLAN-001 | json_schema | explicit_migration | specs/knowledge-architecture/schemas/activation-plan.schema.json | 671ed824740eba6ed3587ce8c2743494cf2b8ade3255764217aacee1768b1de2 | agent_orchestrator, context_evidence, evaluation, skill_runtime |
| CTR-ASSET-001 | json_schema | explicit_migration | specs/knowledge-architecture/schemas/asset-manifest.schema.json | d479c1942b4fd6d51dceac190fedbabb2e048154935299e0fe4ffc063ef897eb | asset_registry, context_evidence, permission_policy |
| CTR-KELEM-001 | json_schema | backward_compatible | specs/knowledge-architecture/schemas/knowledge-element.schema.json | d1a11567b839b601a6f68f6ba20b4466f529f1f2ea0b12149081ac22c0ee785e | agent_orchestrator, asset_registry, knowledge_map_registry |
| CTR-KMAP-001 | json_schema | backward_compatible | specs/knowledge-architecture/schemas/knowledge-map.schema.json | 39bd2ed2fbff5cb74742cf7c9cffb84a96f571fed60d13177800f48d2ce3ef15 | activation_planner, agent_orchestrator, knowledge_map_registry |
| CTR-ROUTE-001 | json_schema | backward_compatible | specs/knowledge-architecture/schemas/route-policy.schema.json | 6f864e35075a4942bdff4d1b91a9afbb21731e4728d32e1efab2d36d216aa043 | activation_planner, route_policy_evaluator |
| CTR-SKILL-002 | json_schema | backward_compatible | specs/knowledge-architecture/schemas/skill-descriptor.schema.json | 59a783e411d626144899b54e38587e27d62c9f625b19e99b8063309fe9c405d6 | activation_planner, agent_orchestrator, skill_registry |
| CTR-API-001, CTR-V11-001, CTR-V11-002, CTR-V11-003, CTR-V11-004 | openapi | backward_compatible | specs/openapi/gits-kno-api.openapi.json | a62a7d7faec48b42f4b033b0975ddb2a5e545a12a55677d530b6a6e3cd5902ac | api_app, frontend_bff_adapter |
| CTR-RULE-001 | dmn | versioned_decision | specs/rules/claim-reconciliation.dmn | f0dabb82ecfdb249b76364bf7d1987a847fb59cc1e47d3178886bf17f8b654bc | context_evidence, policy_rule |
| CTR-SEM-001 | linkml_subset | explicit_migration | specs/semantic/gits-core.linkml.yaml | cc1f8993802583ba393ce8d45c2a5e3b233ef1991530fc7cd92658969807141a | context_evidence, operational_ontology, semantic_runtime |
| CTR-SEM-002 | turtle | explicit_migration | specs/semantic/gits-core.owl.ttl | eddf0f74f0a0d1ad7e26821e158e4838b29872bb2c2a6711351d1a1b9fe0e212 | semantic_runtime |
| CTR-SKILL-001 | json_schema | backward_compatible | specs/skills/context-assembly.skill.schema.json | 954406cf749725c9d9945e305361b9f7cd79cec4bbc723b54c4768b394fbb14e | context_evidence, existing_aios_adapter |

## 3. 读契约的顺序

1. 读`BASELINE_INDEX`和Owner决定，确认需求是否批准；
2. 读`CONTRACT_INDEX`确认ID、Owner、兼容策略、消费者与生成物；
3. 读authority source本身；
4. 读生成脚本和`generated/`，只用于理解，不手改；
5. 读前端SDK、BFF/Controller/DTO/Adapter等消费者；
6. 读合同测试、拒绝路径和Loop证据；
7. 把UI事件映射到合同，不从图片反推正式字段。

## 4. Gap判定树

| 问题 | 是 | 否 |
|---|---|---|
| 既有查询/Action已支持？ | C0复用 | 继续判断 |
| 可由多个既有响应组成View Model？ | C1在BFF/前端组合 | 继续判断 |
| 只是排序、筛选、展示标签、图表或PageReference？ | C1纯展示派生，不写回 | 继续判断 |
| 可安全只读/禁用/降级？ | C2并解释原因 | C3关键Gap，停止实现 |

C3不是“让前端临时补字段”的理由，而是提交Owner决策的理由。

## 5. 受保护契约保持不变时的首选实现

- BFF聚合多个既有查询，返回展示中立View Model；如BFF输出本身属于受控接口，仍须按仓库流程注册，不能暗建旁路API；
- TypeScript intersection/派生类型只容纳本地UI字段，并用命名/注释标识`local`/`derived`；
- 路由、工作区标签、筛选、滚动和草稿引用作为PageReference/UI状态；
- 缺少正式写Action时按钮只读或禁用；不把localStorage当事实库；
- G0—G5、F/C/B/H/P/A、权限、审批和写回结果只展示服务端受控状态。

## 6. 候选修订流程

只有批准需求或Owner变更授权后才允许启动：

1. **登记Gap**：场景、页面、角色、业务后果、当前合同、证据；
2. **穷尽零变更方案**：C0/C1/C2评估及为何不足；
3. **形成候选**：ID、Owner、authority source、兼容类型、消费者、数据/安全/审计影响；
4. **ADR与评审**：Contract Owner、GITS Owner、DKES Owner、业务、数据、安全合规、独立QA；
5. **批准后改源**：先authority source，必要时更新`CONTRACT_INDEX`；
6. **生成与差异**：`make generate`、`make check`、`make contract-diff`、`make contract-verify`；
7. **消费者实现**：后端/BFF/SDK/前端按批准版本更新；
8. **迁移/双跑**：数据、事件、规则或状态变更按兼容策略执行；
9. **回滚验证**：代码、数据、事件、缓存、草稿和前端兼容一起验证；
10. **独立QA与Owner门禁**：通过后才可进入基线或发布。

当前用户要求GITS—DKES契约不能变更，因此发现C3时默认结果是`BLOCKED_OR_DESCOPED`，除非Owner另行明确修改该约束。

## 7. 兼容与迁移要求

| 类型 | 兼容要求 | 迁移/回滚重点 |
|---|---|---|
| OpenAPI/AsyncAPI | 新增可选字段/端点优先；删除、重命名、改类型、收紧必填为breaking | 双版本/双读、消费者升级顺序、旧客户端回滚 |
| LinkML/OWL/SHACL | explicit migration | 语义ID、shape验证、投影重建、历史数据解释 |
| DMN | versioned decision | 规则版本、生效时间、复算范围、旧决定可解释 |
| Action/HumanGate | no silent breaking change | 权限、幂等、原值、回执、补偿、审计责任 |
| Data/R2RML | versioned mapping | 源字段血缘、回填、双跑对账、撤销映射 |
| Evidence/Evaluation | backward compatible或显式版本 | 证据引用稳定、运行清单可重放、旧报告可追溯 |
| Knowledge/Activation/Route/Plan | 按注册表策略 | 路由歧义、技能选择、计划重放、shadow验证 |

## 8. 禁止操作

- 直接覆盖`specs/CONTRACT_INDEX.yaml`或authority source；
- 手工编辑`generated/`；
- 先改Controller/DTO/TypeScript再补合同；
- 在前端新增正式枚举、状态机或权限判断；
- 用V3.2示例字段/状态替代受控合同；
- 未评估消费者就改变共享Schema；
- 未执行拒绝路径、迁移和回滚测试就宣称兼容；
- 将`DESIGN_CANDIDATE`标成已批准基线。

## 9. 候选门禁

| Gate | 必须满足 | 失败结果 |
|---|---|---|
| CC0 Gap有效 | 需求已批准；有证据；C0—C2不足 | 退回分析 |
| CC1 设计可审 | 兼容、消费者、安全、数据、迁移、回滚完整 | 不得改源 |
| CC2 Owner批准 | 合同Owner与业务/系统Owner书面批准 | 保持C2降级 |
| CC3 源与生成一致 | authority source→generate→check通过 | 阻塞实现 |
| CC4 消费者兼容 | 合同/API/SDK/集成/拒绝路径通过 | 不得联调 |
| CC5 独立QA | 迁移、回滚、E2E证据齐全 | 不得发布 |

模板见`08_CONTRACT_CHANGE_CANDIDATE_模板.md`。
