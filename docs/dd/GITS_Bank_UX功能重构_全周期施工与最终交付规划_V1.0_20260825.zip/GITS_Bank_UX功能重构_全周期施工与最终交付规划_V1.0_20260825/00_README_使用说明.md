# GITS Bank UX+功能重构：全周期施工与最终交付规划包

> 版本：V1.0 · 日期：2026-08-25 · 状态：`PLANNING_CANDIDATE`  
> 本包是施工规划与门禁包，不是代码实现、SIT/UAT结论、Owner批准或契约变更授权。

## 1. 结论先行

本包把“立即开工”扩展为从受控接手到最终功能交付的完整路线：P0—P10、W0—W16+参考节奏，覆盖44个目标页面、两条业务闭环、契约零覆盖/候选修订流程、224项V3.2原始用例及40项新增工程发布门禁用例。

最重要的执行规则：

1. 不要把本包或V3.2包解压覆盖到项目仓库。
2. V3.2是`DESIGN_CANDIDATE`，不是`specs/`、`generated/`或实现代码的替换源。
3. GITS—DKES受保护契约默认`NO_CHANGE`；优先使用既有查询、BFF/View Model组合、前端只读派生或安全降级。
4. 发现真实Gap时先停工、建`CONTRACT_CHANGE_CANDIDATE`，未获Owner/Contract Owner批准不得修改authority source，更不得手改`generated/`。
5. 只有独立QA可记录`QA_PASS`；Owner批准前不得标记`PRODUCTION_READY`或`FROZEN`。

## 2. 指定V3.2输入

- 指定资料库路径：`/飞-银行对公知识工程与岗位智能体/GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip`
- 文件名：`GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip`
- SHA-256：`596986aad751c15e38e4c65325ce60c9faede6213575f4d29dce6fc63f1fe0c3`
- 内容基线：44张独立高清图、6张总览、252项需求、224项计划测试、逐页业务/UX说明、契约零变更证据。

## 3. 文件阅读顺序

1. `00_README_使用说明.md`（本文件）
2. `01_GITS_Bank_UX功能重构_全周期交付规划_V1.0.md`
3. `02_Cursor_Tech_Lead_V3.2输入包读取与受控开工指南.md`
4. `03_GITS_DKES_契约读取_候选修订_迁移回滚规范.md`
5. `04_GITS_Bank_测试策略与验证用例集_V1.0.md`
6. `05_GITS_Bank_页面_阶段_契约_测试追踪矩阵.csv`
7. `06_GITS_Bank_测试用例执行矩阵.csv`
8. `07_阶段门禁_交付物_RACI_里程碑矩阵.csv`
9. `08_CONTRACT_CHANGE_CANDIDATE_模板.md`
10. `09_Cursor_Tech_Lead_开工提示词.md`
11. `10_工程WBS与验收任务清单.csv`
12. `evidence/`和`QUALITY_REPORT.md`

## 4. 当前核验基线

| 项目 | 值 |
|---|---|
| 仓库分支/提交 | `main` / `d3142c9557aaa197c41ef89343ec1e05b073d0a0` |
| 仓库工作区 | `CLEAN` |
| CONTRACT_INDEX SHA-256 | `6606a8b64f0dd0e06091f6d46911042eb437de70ea65df417840e985819a57d5` |
| 契约记录 / 唯一authority source | 25 / 21 |
| V3.2 ZIP SHA-256 | `596986aad751c15e38e4c65325ce60c9faede6213575f4d29dce6fc63f1fe0c3` |
| 规划状态 | `PLANNING_CANDIDATE` |
| 实施/SIT/UAT | `NOT_EXECUTED` |

## 5. Cursor的正确使用方式

把仓库和解压后的参考包作为两个独立根目录读取；先开“只读Tech Lead会话”做追踪和Gap判断，再由获授权的Feature Pilot会话写实现。具体命令、停工条件和提示词见02、08、09号文档。
