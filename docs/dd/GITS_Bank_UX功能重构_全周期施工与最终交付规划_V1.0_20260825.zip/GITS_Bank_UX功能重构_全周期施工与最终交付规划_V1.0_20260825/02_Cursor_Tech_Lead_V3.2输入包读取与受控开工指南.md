# Cursor Tech Lead：读取V3.2输入包与受控开工指南

> 目的：告诉Cursor中的Tech Lead如何读、如何建追踪、如何派工、何时停；不授权它直接覆盖项目目录或契约。

## 1. 两个根目录，绝不混放

建议建立同级目录：

```text
<workspace>/gits-knowledge-engineering/          # Git仓库
<workspace>/_reference/gits-bank-v3.2/          # 解压后的只读设计参考
<workspace>/_reference/gits-bank-delivery-plan/ # 本规划包
```

不得把V3.2或本规划包解压到仓库根目录；不得复制覆盖`specs/`、`generated/`、`apps/`、`modules/`、`adapters/`、`frontend/`、`loops/`或`docs/dispatch/`。

先校验：

```bash
sha256sum GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip
# 期望：596986aad751c15e38e4c65325ce60c9faede6213575f4d29dce6fc63f1fe0c3
unzip -t GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip
unzip -l GITS_Bank_对公客户经营UX与功能全量重构_V3.2_20260825.zip
```

Cursor可使用多根工作区：把仓库作为唯一可写根，把两个`_reference`目录作为只读参考根。若无法强制只读，至少在会话规则中声明“参考目录禁止写回仓库”。

## 2. 第一个Cursor会话必须是Tech Lead只读接手

不要一开始要求“按图实现全部页面”。按以下顺序读取：

### 2.1 仓库权威输入

1. `AGENTS.md`
2. `AI_GUIDE.md`
3. `.codebuddy/rules/`中alwaysApply规则，以及将触及路径对应规则
4. `specs/BASELINE_INDEX.yaml`
5. 当前active dispatch和active Loop的`LOOP.yaml`、`STATE.json`、`EVIDENCE.md`
6. `memory/NEXT_SESSION.md`和`ROLE_BOARD.yaml`，确认Baton
7. `specs/CONTRACT_INDEX.yaml`
8. 注册表全部authority source及其consumers/generated
9. 当前前端路由、App Shell、API类型、测试与CI

### 2.2 V3.2参考包

1. `README_交付说明.md`
2. `GITS_Bank_对公客户经营_前端UX与操作需求_V3.2_20260825.md`
3. `GITS_Bank_页面导航与操作逻辑矩阵_V3.2_20260825.md`
4. `GITS_Bank_V3.2_设计系统与组件规范.md`
5. `GITS_Bank_全量功能清单与测试验证用例_V3.2.md`
6. `GITS_DKES_契约保护与兼容性核验_V3.2.md`
7. `界面清单与追踪_V3.2.json`
8. `images/`逐页图；`overviews/`只用于索引

### 2.3 本规划包

先读01—04，再把05—07导入任务/测试管理工具；08只用于发现真实Gap；09用于启动受控会话。

## 3. 开工快照

在仓库根目录只读执行并保存输出：

```bash
git status --short
git branch --show-current
git rev-parse HEAD
sha256sum specs/CONTRACT_INDEX.yaml
python3 - <<'PY'
import hashlib, json, pathlib
p=pathlib.Path('specs/CONTRACT_INDEX.yaml')
d=json.loads(p.read_text())
sources=sorted({c['authority_source'] for c in d['contracts']})
assert sources, 'contract registry parsed zero authority sources'
for s in sources:
    f=pathlib.Path(s)
    assert f.is_file(), s
    print(hashlib.sha256(f.read_bytes()).hexdigest(), s)
print('authority_source_count', len(sources))
PY
```

当前参考点是`main@d3142c9557aaa197c41ef89343ec1e05b073d0a0`、CONTRACT_INDEX `6606a8b64f0dd0e06091f6d46911042eb437de70ea65df417840e985819a57d5`、21个唯一authority source。Tech Lead必须以实际开工时仓库状态为准，若不同则生成新的差异报告，不能把旧哈希强行“恢复”到仓库。

## 4. Tech Lead的第一份输出，不是代码

必须先产出并由Owner确认：

- 当前Loop/Baton与是否允许创建新Loop；
- 44页→现有路由/组件/API/合同/测试的差距矩阵；
- 每个主动作C0/C1/C2/C3判定；
- Node/CI/E2E/contract-check等开工阻塞修复包；
- P2 Shell和首个垂直切片的派工、门禁、exit criteria；
- 不修改受保护契约的实现方案；
- 未决业务/数据/权限问题及Owner决策点。

没有G1批准，不进入大规模页面编码。

## 5. 新Loop与角色隔离

仅在Owner确认后使用仓库命令创建新Loop；Loop ID以仓库实际序列和命名政策为准。候选示例：

```bash
make new-loop LOOP=P23-gits-bank-ux-foundation HOLDER=tech_lead
```

Tech Lead会话负责架构、追踪、合同候选和派工，不直接混写Feature实现。切换Feature Pilot时重新确认Loop、scope、gate、Baton；切换E2E Owner时确认开发证据齐全，E2E Owner不得改实现来“修绿”。

## 6. 如何从V3.2落到代码

对每页按固定卡片处理：

```text
Page ID / Requirement IDs
→ 业务对象与用户目标
→ 入口/主动作/下一页/返回上下文
→ Query与Command
→ 合同ID / authority source / consumer
→ C0/C1/C2/C3
→ Feature文件与路由
→ Unit/Component/Contract/E2E Test IDs
→ Evidence
```

静态图中的字段、数字、状态、按钮都不是自动授权。没有合同支持时：

- 查询组合：放View Model/BFF；
- 纯展示派生：用显式本地类型/`computed`，不写回；
- 写动作缺失：禁用/只读/降级并说明；
- 关键能力不可实现：建候选Gap并停工，不在前端伪造。

## 7. 契约更新的正确含义

“更新契约”不是让Cursor编辑`generated/`或在前端补字段。只有在批准的需求/Owner决定授权后：

1. 形成`CONTRACT_CHANGE_CANDIDATE`；
2. Contract Owner、GITS/DKES Owner、消费者、安全/合规、独立QA评审；
3. 获批后先改authority source；
4. 更新注册表（新增/版本变化时）；
5. `make generate && make check`；
6. `make contract-diff BASELINE=<受控基线目录>`与`make contract-verify`；
7. 再改SDK、BFF、前端/后端消费者；
8. 执行迁移、双跑/兼容和回滚测试；
9. 独立QA与Owner决定是否进入新基线。

在当前“GITS—DKES契约不能变更”的约束下，C3只形成阻塞与决策材料，不得擅自进入第3步。

## 8. 每个PR必须包含

- Loop ID、Page IDs、Requirement IDs、Contract IDs、Test IDs；
- 变更前后用户行为与截图/视觉差异；
- 四态、权限、异常、返回/恢复、a11y测试；
- 若无契约变更，明确`CONTRACT_CHANGE=NONE`并附检查；
- 若有批准候选，附ADR、兼容/迁移/回滚和消费者测试；
- 显式`git add <paths>`，不得`git add .`；
- 失败先写`FAILURES.md`再修；不得由开发者写`QA_PASS`。

## 9. Cursor必须停止的条件

- Baton不属于当前角色或Loop scope不含目标工作；
- 找不到唯一active dispatch/Loop或权威状态冲突；
- 页面动作需要新正式字段/状态/枚举/权限/Action；
- 受保护authority source发生未批准变化；
- 测试依赖未授权真实数据、密钥或外部系统；
- 需要启用quarantine中的Oracle/Ossie而无ADR和数据Owner授权；
- 关键失败未留证据、或有人要求开发角色自签QA/上线。

## 10. 如何使用本规划包中的表格

- 05 CSV：导入需求/开发工具，一行一个页面；用`phase`和`page_id`建Epic/Feature；不得把`target_route_candidate`当后端合同。
- 06 CSV：导入测试管理工具；先保留`PLANNED`，执行后填build/commit/env/actor/result/evidence/defect。
- 07 CSV：建立里程碑和RACI；每个gate的Approver不能被Implementer代替。
- 08 MD：仅复制为新的候选记录，不覆盖现有合同文件。
- 09 MD：作为Cursor短提示词；仍须由Cursor真实读取仓库，而非相信提示词中的历史状态。
- 10 CSV：拆分为工程看板任务；依赖仅是初始候选，Tech Lead可在不破坏Gate的前提下并行化，但不得把跨Gate依赖删掉。
